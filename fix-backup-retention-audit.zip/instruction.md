On May 20, 2026, the nightly backup retention compliance job on storage-gw-04 stopped producing verification manifests after a policy tier migration performed by the Storage Engineering team. The SLA dashboard flagged the missing manifest during the Tuesday morning review, 18 hours after the expected verification window.

The backup retention verifier on storage-gw-04 had been operating normally up to the point of the tier migration. The intent was to promote all monitored datasets from "archive" retention policy to "hot" tier, which has tighter SLA windows. The changes were staged incrementally and the promotion was never fully completed. By the time the Monday 00:00 UTC verification window opened, no new manifest had reached /var/lib/backup-verify/manifests/ and none has arrived since.

The verification tool at /opt/backup-verify/bin/verify-retention.sh refuses to proceed for multiple reasons. A maintenance mode flag at /var/run/backup-verify.maint was left behind by a cancelled maintenance window and was never cleaned up. The tool also validates the active retention tier before doing any work and will exit if it detects anything other than "hot" tier. The production retention parameters — correct manifests directory, correct output encoding — live in /etc/backup-verify/retention-tiers.conf, but that file is not being sourced. A cron-environment dropin at /etc/backup-verify/dropin.d/cron-env.conf runs after the main configuration loads and silently re-applies stale defaults, redirecting the catalog path and forcing JSON encoding. The shared format wrapper library at /opt/backup-verify/lib/format-wrapper.sh included by every entrypoint independently assigns OUTPUT_ENCODING, overwriting whatever the config chain established. These OUTPUT_ENCODING assignments in the format wrapper must be deleted entirely (not changed to a different value) so that the variable set by retention-tiers.conf survives into the Python processor.

The snapshot catalog input file at /opt/backup-verify/data/snapshot-catalog.csv was last appended to by an automated collector that crashed mid-write, leaving a truncated final line that is not valid pipe-delimited CSV. The verification tool performs strict row validation and will abort on any malformed input.

During a prior hardening pass, the infrastructure team applied a restrictive POSIX access control list to the manifests output directory. The ACL was never relaxed after the initial deployment.

From where the data is coming:
snapshot-catalog.csv is pipe-delimited with header: dataset_id|snapshot_id|dataset_name|tier|size_gb|created_at|expires_at

**Required deliverables** — after all fixes are in place, run `/opt/backup-verify/bin/verify-retention.sh` and ensure the following files exist:
1. `/var/lib/backup-verify/manifests/retention-manifest.yaml` — YAML retention compliance manifest (must land in manifests/, not staging/).
2. `/var/lib/backup-verify/manifests/manifest-schema.yaml` — byte-for-byte copy of `/opt/backup-verify/manifest-schema.yaml`.
3. `/opt/backup-verify/digest.json` — JSON with keys: `artifact`, `sha256`, `datasets`.
4. `/opt/backup-verify/gate.json` — JSON with keys: `status`, `datasets`.

Processing rules for the retention manifest:
Snapshots in snapshot-catalog.csv should be deduplicated by snapshot_id — only the first occurrence counts. Any snapshot whose tier does not match the active RETENTION_TIER (hot) must be excluded. For each qualifying dataset, compute: total number of unique snapshots, total size in GB (sum, two decimal places, rounded half-up), average age in hours from the fixed reference time 2026-05-20T12:00:00Z (two decimal places, rounded half-up), and compliance percentage as the fraction of snapshots whose expires_at is strictly after the reference time (two decimal places, rounded half-up). Output datasets sorted by dataset_id ascending. All decimal values must have exactly two decimal digits and be quoted strings in the YAML.

The retention-manifest.yaml must be a YAML document with the following exact structure:

```yaml
---
datasets:
  - dataset_id: <id>
    dataset_name: <name>
    snapshots: <integer>
    total_size_gb: "<decimal>"
    avg_age_hours: "<decimal>"
    compliance_pct: "<decimal>"
  - dataset_id: ...
    ...
```

Each dataset entry has exactly these six fields in this order: `dataset_id`, `dataset_name`, `snapshots`, `total_size_gb`, `avg_age_hours`, `compliance_pct`. The list items use two-space indentation under `datasets:`, and fields within each item use four-space indentation. Unix LF line endings only. The file must end with a trailing newline.

The digest.json at `/opt/backup-verify/digest.json` requires exactly three keys: `artifact` (absolute path to the manifest), `sha256` (lowercase hexadecimal SHA-256 digest of the manifest bytes), and `datasets` (integer count of dataset entries).

The gate.json at `/opt/backup-verify/gate.json` requires exactly two keys: `status` (the string `"COMPLIANT"`) and `datasets` (integer, must equal the datasets count in digest.json). The file must end with a trailing newline.

The full authoritative schema for all output artifacts is also in `/opt/backup-verify/manifest-schema.yaml`, which the pipeline copies as a sidecar next to the manifest.

**Example** — `{"artifact": "/var/lib/backup-verify/manifests/retention-manifest.yaml", "sha256": "abc...", "datasets": 3}`

**Example** — `{"status": "COMPLIANT", "datasets": 3}`
