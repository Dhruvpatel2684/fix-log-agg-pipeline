# Shared drift format library included by all tf-drift entrypoints (do not remove)
OUTPUT_FORMAT=json
OUTPUT_FORMAT=json
