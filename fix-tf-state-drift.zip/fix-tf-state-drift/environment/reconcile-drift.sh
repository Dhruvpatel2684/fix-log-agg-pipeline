#!/bin/bash
# Weekly Terraform state drift reconciliation
set -euo pipefail

PID_LOCK=/var/run/tf-drift.pid
if [[ -f "$PID_LOCK" ]]; then
  echo "tf-drift: another instance is running (lock $PID_LOCK present)" >&2
  exit 2
fi

CONFIG=/etc/tf-drift/tf-drift.conf
# shellcheck source=/dev/null
source "$CONFIG"

scope="${DRIFT_SCOPE:-workspace}"
if [[ "${scope,,}" != "module" ]]; then
  echo "tf-drift refused: DRIFT_SCOPE must be 'module' in ${CONFIG}" >&2
  exit 1
fi

# shellcheck source=/dev/null
source /opt/tf-drift/lib/drift-formatter.sh

CATALOG="${STATE_CATALOG:-/opt/tf-drift/data/state-catalog.tsv}"
REPORT="${REPORTS_DIR}/drift-report.yaml"
DIGEST=/opt/tf-drift/digest.json
GATE=/opt/tf-drift/gate.json
REFERENCE_TIME="2026-05-20T00:00:00Z"

mkdir -p "$REPORTS_DIR"

python3 - "$CATALOG" "$REPORT" "$OUTPUT_FORMAT" "$DIGEST" "$GATE" "$REFERENCE_TIME" "$scope" <<'PY'
import csv
import json
import hashlib
import sys
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

catalog_path, report_path, fmt, digest_path, gate_path, ref_time_str, active_scope = sys.argv[1:8]

if fmt not in ("yaml",):
    sys.exit("Unsupported format")

ref_time = datetime.fromisoformat(ref_time_str.replace("Z", "+00:00"))
plan_window_hours = 72  # 3 days

SEVERITY_WEIGHTS = {"critical": 4, "high": 3, "medium": 2, "low": 1}

# Parse state catalog (tab-delimited)
seen_resources: set = set()
modules: dict = {}

with open(catalog_path, newline="", encoding="utf-8") as fh:
    reader = csv.DictReader(fh, delimiter="\t")
    for lineno, row in enumerate(reader, 2):
        required = {"resource_id", "module", "resource_name", "scope", "drift_type", "severity", "provider", "region", "last_plan", "last_apply"}
        missing = required - set(row.keys())
        if missing:
            sys.exit(f"state-catalog.tsv:{lineno}: missing fields {missing}")
        for key in required:
            if row[key] is None or row[key].strip() == "":
                sys.exit(f"state-catalog.tsv:{lineno}: empty value for '{key}'")

        resource_id = row["resource_id"].strip()
        if resource_id in seen_resources:
            continue
        seen_resources.add(resource_id)

        row_scope = row["scope"].strip().lower()
        if row_scope != active_scope:
            continue

        module = row["module"].strip()
        drift_type = row["drift_type"].strip().lower()
        severity = row["severity"].strip().lower()
        last_plan = datetime.fromisoformat(row["last_plan"].strip().replace("Z", "+00:00"))

        hours_since_plan = Decimal(str((ref_time - last_plan).total_seconds())) / Decimal("3600")
        is_fresh = hours_since_plan <= Decimal(str(plan_window_hours))

        if module not in modules:
            modules[module] = {
                "total": 0,
                "destructive": 0,
                "attribute": 0,
                "severity_sum": Decimal(0),
                "fresh_plans": 0,
            }
        m = modules[module]
        m["total"] += 1
        if drift_type == "destructive":
            m["destructive"] += 1
        elif drift_type == "attribute":
            m["attribute"] += 1
        m["severity_sum"] += Decimal(str(SEVERITY_WEIGHTS.get(severity, 1)))
        if is_fresh:
            m["fresh_plans"] += 1

# Build YAML output (manual formatting for deterministic output)
lines = ["---", "modules:"]
for module_name in sorted(modules.keys()):
    m = modules[module_name]
    avg_severity = (m["severity_sum"] / Decimal(m["total"])).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    freshness_pct = (Decimal(m["fresh_plans"]) / Decimal(m["total"]) * 100).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    lines.append(f"  - module: {module_name}")
    lines.append(f"    total_resources: {m['total']}")
    lines.append(f"    destructive_drifts: {m['destructive']}")
    lines.append(f"    attribute_drifts: {m['attribute']}")
    lines.append(f'    avg_severity_score: "{avg_severity}"')
    lines.append(f'    plan_freshness_pct: "{freshness_pct}"')

yaml_content = "\n".join(lines) + "\n"
Path(report_path).write_text(yaml_content, encoding="utf-8")

# Generate digest
digest = hashlib.sha256(yaml_content.encode("utf-8")).hexdigest()
module_count = len(modules)
digest_obj = {
    "artifact": str(report_path),
    "sha256": digest,
    "modules": module_count,
}
Path(digest_path).write_text(json.dumps(digest_obj, indent=2) + "\n")

# Generate gate
Path(gate_path).write_text(
    json.dumps({"status": "RECONCILED", "modules": module_count}) + "\n"
)

# Copy schema as sidecar
schema_src = Path("/opt/tf-drift/drift-schema.yaml")
sidecar = Path(report_path).parent / "drift-schema.yaml"
sidecar.write_text(schema_src.read_text(encoding="utf-8"), encoding="utf-8")
PY
