On May 20, 2026, the weekly Terraform state drift reconciliation on platform-ctrl-01 stopped producing audit reports after a workspace migration performed by the Platform Engineering team. The drift dashboard flagged the missing report during the Tuesday morning review, 48 hours after the expected reconciliation window.

The drift audit tool on platform-ctrl-01 had been operating normally up to the point of the workspace migration. The intent was to migrate all monitored resource tracking from "workspace" scope to "module" scope, which covers module-level resource groupings with tighter plan freshness SLAs. The changes were staged incrementally and the migration was never fully completed. By the time the Sunday 00:00 UTC reconciliation window opened, no new report had reached /var/lib/tf-drift/reports/ and none has arrived since.

The reconciliation tool at /opt/tf-drift/bin/reconcile-drift.sh refuses to proceed for multiple reasons. A stale PID lock file was left behind by a previous run that was killed mid-execution and was never cleaned up. The tool also validates the active drift scope before doing any work and will exit if it detects anything other than "module" scope. The production audit parameters — correct reports directory, correct output format — live in a provider defaults configuration file, but that file is not being sourced. A sandbox environment shim runs after the main configuration loads and silently re-applies stale defaults, redirecting the state catalog path and forcing JSON format. The shared drift formatter library included by every entrypoint independently assigns OUTPUT_FORMAT, overwriting whatever the config chain established. These OUTPUT_FORMAT assignments in the drift formatter must be deleted entirely (not changed to a different value) so that the variable set by the provider defaults survives into the Python processor.

The state catalog input file was last appended to by an automated collector that crashed mid-write, leaving a truncated final line that is not valid tab-delimited TSV. The reconciliation tool performs strict row validation and will abort on any malformed input.

During a prior hardening pass, the infrastructure team applied a restrictive POSIX access control list to the reports output directory. The ACL was never relaxed after the initial deployment.

From where the data is coming:
state-catalog.tsv is tab-delimited with header: resource_id	module	resource_name	scope	drift_type	severity	provider	region	last_plan	last_apply

**Required deliverables** — after all fixes are in place, run `/opt/tf-drift/bin/reconcile-drift.sh` and ensure the following files exist:
1. `/var/lib/tf-drift/reports/drift-report.yaml` — YAML drift report (must land in reports/, not staging/).
2. `/var/lib/tf-drift/reports/drift-schema.yaml` — byte-for-byte copy of `/opt/tf-drift/drift-schema.yaml`.
3. `/opt/tf-drift/digest.json` — JSON with keys: `artifact`, `sha256`, `modules`.
4. `/opt/tf-drift/gate.json` — JSON with keys: `status`, `modules`.

Processing rules for the drift report:
Resources in state-catalog.tsv should be deduplicated by resource_id — only the first occurrence counts. Any resource whose scope does not match the active DRIFT_SCOPE (module) must be excluded. For each qualifying module, compute: total number of unique resources, count of destructive drifts, count of attribute drifts (only drift_type values exactly matching "destructive" or "attribute" are counted in their respective fields), average severity score (using weights: critical=4, high=3, medium=2, low=1; two decimal places, rounded half-up), and plan freshness percentage as the fraction of resources whose last_plan is within 72 hours (3 days) of the fixed reference time 2026-05-20T00:00:00Z (two decimal places, rounded half-up). Output modules sorted by module name ascending. All decimal values must have exactly two decimal digits and be quoted strings in the YAML.

The drift-report.yaml must be a YAML document with the following exact structure:

```yaml
---
modules:
  - module: <name>
    total_resources: <integer>
    destructive_drifts: <integer>
    attribute_drifts: <integer>
    avg_severity_score: "<decimal>"
    plan_freshness_pct: "<decimal>"
  - module: ...
    ...
```

Each module entry has exactly these six fields in this order: `module`, `total_resources`, `destructive_drifts`, `attribute_drifts`, `avg_severity_score`, `plan_freshness_pct`. The list items use two-space indentation under `modules:`, and fields within each item use four-space indentation. Unix LF line endings only. The file must end with a trailing newline.

The digest.json at `/opt/tf-drift/digest.json` requires exactly three keys: `artifact` (absolute path to the report), `sha256` (lowercase hexadecimal SHA-256 digest of the report bytes), and `modules` (integer count of module entries).

The gate.json at `/opt/tf-drift/gate.json` requires exactly two keys: `status` (the string `"RECONCILED"`) and `modules` (integer, must equal the modules count in digest.json). The file must end with a trailing newline.

The full authoritative schema for all output artifacts is also in `/opt/tf-drift/drift-schema.yaml`, which the pipeline copies as a sidecar next to the report.

**Example** — `{"artifact": "/var/lib/tf-drift/reports/drift-report.yaml", "sha256": "abc...", "modules": 4}`

**Example** — `{"status": "RECONCILED", "modules": 4}`
