#!/bin/bash
set -euo pipefail

CONFIG=/etc/tf-drift/tf-drift.conf
FORMATTER=/opt/tf-drift/lib/drift-formatter.sh
CATALOG=/opt/tf-drift/data/state-catalog.tsv

# 1. Remove stale PID lock file
rm -f /var/run/tf-drift.pid

# 2. Switch DRIFT_SCOPE from workspace to module
sed -i 's/^DRIFT_SCOPE=workspace$/#DRIFT_SCOPE=workspace/' "$CONFIG"
sed -i 's/^#DRIFT_SCOPE=module$/DRIFT_SCOPE=module/' "$CONFIG"

# 3. Enable sourcing of provider-defaults.conf (production overrides)
sed -i 's|^# \. /etc/tf-drift/provider-defaults\.conf$|. /etc/tf-drift/provider-defaults.conf|' "$CONFIG"

# 4. Neutralize the sandbox shim
sed -i 's|^\. /etc/tf-drift/overrides\.d/sandbox-shim\.conf$|# . /etc/tf-drift/overrides.d/sandbox-shim.conf|' "$CONFIG"

# 5. Remove OUTPUT_FORMAT clobber from drift formatter (delete, not change)
tmp="$(mktemp)"
grep -v '^OUTPUT_FORMAT=' "$FORMATTER" >"$tmp"
mv "$tmp" "$FORMATTER"

# 6. Clear restrictive POSIX ACL on reports directory
setfacl -b /var/lib/tf-drift/reports
chmod 755 /var/lib/tf-drift/reports

# 7. Remove corrupt trailing line from state catalog
sed -i '$ { /^{/d }' "$CATALOG"

# 8. Execute the reconciliation pipeline
/opt/tf-drift/bin/reconcile-drift.sh
