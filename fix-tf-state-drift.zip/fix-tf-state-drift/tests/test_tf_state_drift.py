"""
Tests for fix-tf-state-drift.
All tests must fail on the initial state and pass after solve.sh runs.
"""

from __future__ import annotations

import csv
import hashlib
import json
import subprocess
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

SCHEMA = Path("/opt/tf-drift/drift-schema.yaml")
REPORTS_DIR = Path("/var/lib/tf-drift/reports")
STAGING_DIR = Path("/var/lib/tf-drift/staging")
REPORT = REPORTS_DIR / "drift-report.yaml"
SIDECAR = REPORTS_DIR / "drift-schema.yaml"
DIGEST = Path("/opt/tf-drift/digest.json")
GATE = Path("/opt/tf-drift/gate.json")
CONFIG = Path("/etc/tf-drift/tf-drift.conf")
FORMATTER = Path("/opt/tf-drift/lib/drift-formatter.sh")
CATALOG = Path("/opt/tf-drift/data/state-catalog.tsv")
PID_LOCK = Path("/var/run/tf-drift.pid")
EXPECTED_MODULES = 4
REFERENCE_TIME = "2026-05-20T00:00:00Z"
ACTIVE_SCOPE = "module"
PLAN_WINDOW_HOURS = 72

SEVERITY_WEIGHTS = {"critical": 4, "high": 3, "medium": 2, "low": 1}

EXPECTED_YAML_LINES = [
    "---",
    "modules:",
    "  - module: compute",
    "    total_resources: 4",
    "    destructive_drifts: 1",
    "    attribute_drifts: 2",
    '    avg_severity_score: "1.75"',
    '    plan_freshness_pct: "50.00"',
    "  - module: monitoring",
    "    total_resources: 3",
    "    destructive_drifts: 0",
    "    attribute_drifts: 2",
    '    avg_severity_score: "2.00"',
    '    plan_freshness_pct: "66.67"',
    "  - module: networking",
    "    total_resources: 3",
    "    destructive_drifts: 1",
    "    attribute_drifts: 2",
    '    avg_severity_score: "3.00"',
    '    plan_freshness_pct: "100.00"',
    "  - module: storage",
    "    total_resources: 4",
    "    destructive_drifts: 1",
    "    attribute_drifts: 2",
    '    avg_severity_score: "2.25"',
    '    plan_freshness_pct: "75.00"',
]


def _derive_expected_from_inputs() -> str:
    """Derive expected YAML by applying business rules to on-disk inputs."""
    ref_time = datetime.fromisoformat(REFERENCE_TIME.replace("Z", "+00:00"))
    seen: set = set()
    modules: dict = {}

    with CATALOG.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh, delimiter="\t")
        for lineno, row in enumerate(reader, 2):
            required = {"resource_id", "module", "resource_name", "scope", "drift_type", "severity", "provider", "region", "last_plan", "last_apply"}
            if not required.issubset(set(row.keys())):
                continue
            if any(row[k] is None or row[k].strip() == "" for k in required):
                continue
            try:
                resource_id = row["resource_id"].strip()
                if resource_id in seen:
                    continue
                seen.add(resource_id)
                if row["scope"].strip().lower() != ACTIVE_SCOPE:
                    continue
                module = row["module"].strip()
                drift_type = row["drift_type"].strip().lower()
                severity = row["severity"].strip().lower()
                last_plan = datetime.fromisoformat(row["last_plan"].strip().replace("Z", "+00:00"))
                hours_since = Decimal(str((ref_time - last_plan).total_seconds())) / Decimal("3600")
                is_fresh = hours_since <= Decimal(str(PLAN_WINDOW_HOURS))
                if module not in modules:
                    modules[module] = {"total": 0, "destructive": 0, "attribute": 0, "severity_sum": Decimal(0), "fresh_plans": 0}
                m = modules[module]
                m["total"] += 1
                if drift_type == "destructive":
                    m["destructive"] += 1
                elif drift_type == "attribute":
                    m["attribute"] += 1
                m["severity_sum"] += Decimal(str(SEVERITY_WEIGHTS.get(severity, 1)))
                if is_fresh:
                    m["fresh_plans"] += 1
            except (ValueError, KeyError):
                continue

    lines = ["---", "modules:"]
    for module_name in sorted(modules.keys()):
        m = modules[module_name]
        avg_severity = (m["severity_sum"] / Decimal(m["total"])).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        freshness_pct = (Decimal(m["fresh_plans"]) / Decimal(m["total"]) * 100).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        lines.append(f"  - module: {module_name}")
        lines.append(f"    total_resources: {m['total']}")
        lines.append(f"    destructive_drifts: {m['destructive']}")
        lines.append(f"    attribute_drifts: {m['attribute']}")
        lines.append(f'    avg_severity_score: "{avg_severity}"')
        lines.append(f'    plan_freshness_pct: "{freshness_pct}"')
    return "\n".join(lines) + "\n"


def test_schema_file_exists() -> None:
    """Environment must ship the drift schema."""
    assert SCHEMA.is_file(), "missing /opt/tf-drift/drift-schema.yaml"


def test_pid_lock_absent() -> None:
    """Stale PID lock must be removed before the pipeline can run."""
    assert not PID_LOCK.exists(), \
        f"PID lock {PID_LOCK} still present — pipeline will refuse to start"


def test_catalog_no_corrupt_lines() -> None:
    """Every non-header line in state-catalog.tsv must be valid tab-delimited data."""
    with CATALOG.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh, delimiter="\t")
        for lineno, row in enumerate(reader, 2):
            required = {"resource_id", "module", "resource_name", "scope", "drift_type", "severity", "provider", "region", "last_plan", "last_apply"}
            missing = required - set(row.keys())
            assert not missing, f"state-catalog.tsv:{lineno}: missing fields {missing}"
            for key in required:
                assert row[key] is not None and row[key].strip() != "", \
                    f"state-catalog.tsv:{lineno}: empty value for '{key}'"


def test_config_drift_scope_module() -> None:
    """Drift scope must be 'module' and provider-defaults.conf must be sourced."""
    text = CONFIG.read_text(encoding="utf-8")
    lines = [ln.strip() for ln in text.splitlines()]
    assert "DRIFT_SCOPE=module" in lines, "DRIFT_SCOPE=module must be uncommented in tf-drift.conf"
    assert ". /etc/tf-drift/provider-defaults.conf" in lines, \
        "provider-defaults.conf must be sourced from tf-drift.conf"
    active_workspace = [ln for ln in lines if ln == "DRIFT_SCOPE=workspace"]
    assert not active_workspace, "workspace scope must not remain active in tf-drift.conf"


def test_config_sandbox_shim_neutralized() -> None:
    """Sandbox override shim must be commented out — STRICT check."""
    text = CONFIG.read_text(encoding="utf-8")
    assert "# . /etc/tf-drift/overrides.d/sandbox-shim.conf" in text or (
        ". /etc/tf-drift/overrides.d/sandbox-shim.conf" not in text
    ), "neutralize sandbox shim in tf-drift.conf"


def test_formatter_does_not_override_format() -> None:
    """Drift formatter must not set OUTPUT_FORMAT (clobbers yaml). Lines must be deleted entirely."""
    text = FORMATTER.read_text(encoding="utf-8")
    for raw in text.splitlines():
        stripped = raw.lstrip()
        if stripped.startswith("#"):
            continue
        assert not stripped.startswith("OUTPUT_FORMAT="), \
            "drift-formatter.sh must not set OUTPUT_FORMAT — delete the lines entirely"


def test_reports_dir_no_restrictive_acl() -> None:
    """Reports directory must not have a POSIX ACL that blocks write access."""
    result = subprocess.run(
        ["/bin/bash", "-c", f"getfacl --absolute-names {REPORTS_DIR}"],
        capture_output=True, text=True, check=False,
    )
    if result.returncode == 0:
        for line in result.stdout.splitlines():
            stripped = line.strip()
            if stripped.startswith("user::"):
                perms = stripped.split("::")[1]
                assert "w" in perms, \
                    f"reports directory owner ACL denies write: {stripped}"
    probe = REPORTS_DIR / ".write_probe"
    probe.write_text("ok\n", encoding="utf-8")
    probe.unlink()


def test_report_file_exists() -> None:
    """Primary deliverable must land in the reports directory."""
    assert REPORT.is_file(), "drift-report.yaml missing from reports directory"


def test_staging_has_no_report() -> None:
    """Partial fixes that write to staging must not satisfy compliance."""
    staging_yaml = STAGING_DIR / "drift-report.yaml"
    assert not staging_yaml.is_file(), "drift-report.yaml must not be in staging"


def test_sidecar_schema_beside_report() -> None:
    """Pipeline must emit schema sidecar next to report."""
    assert SIDECAR.is_file(), "missing drift-schema.yaml sidecar"
    published = SCHEMA.read_text(encoding="utf-8")
    sidecar = SIDECAR.read_text(encoding="utf-8")
    assert sidecar == published, "sidecar must mirror /opt/tf-drift/drift-schema.yaml"


def test_report_yaml_structure() -> None:
    """Report must be valid YAML with correct structure and values."""
    raw = REPORT.read_bytes()
    assert b"\r" not in raw, "drift-report.yaml must use Unix LF only"
    assert raw.endswith(b"\n"), "drift-report.yaml must end with trailing newline"
    lines = raw.decode("utf-8").splitlines()
    assert lines == EXPECTED_YAML_LINES, \
        f"report content mismatch:\nGOT:\n" + "\n".join(lines[:5]) + "..."


def test_report_excludes_workspace_scope() -> None:
    """Workspace-scope resources must be excluded from the report."""
    text = REPORT.read_text(encoding="utf-8")
    assert "dns" not in text.lower().split("module:")[0] if "module:" in text.lower() else True
    # More direct check: dns module should not appear
    for line in text.splitlines():
        if line.strip().startswith("- module:"):
            module_name = line.strip().split("- module:")[1].strip()
            assert module_name != "dns", "workspace-scope module 'dns' must be excluded"


def test_report_matches_derived_expectation() -> None:
    """Output must match rules applied to on-disk catalog."""
    derived = _derive_expected_from_inputs()
    actual = REPORT.read_text(encoding="utf-8")
    assert actual == derived, "report does not match derived expectation from catalog"


def test_digest_matches_schema() -> None:
    """digest.json must follow schema and match the artifact."""
    digest_obj = json.loads(DIGEST.read_text(encoding="utf-8"))
    assert set(digest_obj.keys()) == {"artifact", "sha256", "modules"}
    computed = hashlib.sha256(REPORT.read_bytes()).hexdigest()
    assert digest_obj["sha256"] == computed
    assert digest_obj["modules"] == EXPECTED_MODULES
    assert digest_obj["artifact"] == str(REPORT)


def test_gate_matches_schema() -> None:
    """gate.json must use status RECONCILED and modules matching digest."""
    raw = GATE.read_bytes()
    assert raw.endswith(b"\n"), "gate.json must end with trailing newline"
    gate = json.loads(raw.decode("utf-8"))
    assert set(gate.keys()) == {"status", "modules"}
    assert gate["status"] == "RECONCILED"
    digest_obj = json.loads(DIGEST.read_text(encoding="utf-8"))
    assert gate["modules"] == digest_obj["modules"] == EXPECTED_MODULES


def test_pipeline_exits_zero() -> None:
    """Re-running the pipeline must succeed."""
    result = subprocess.run(
        ["/bin/bash", "/opt/tf-drift/bin/reconcile-drift.sh"],
        capture_output=True, text=True, check=False,
    )
    assert result.returncode == 0, result.stderr or result.stdout


def test_pipeline_rerun_is_byte_identical() -> None:
    """Second run must produce identical output (idempotent)."""
    before_report = REPORT.read_bytes()
    before_digest = DIGEST.read_bytes()
    result = subprocess.run(
        ["/bin/bash", "/opt/tf-drift/bin/reconcile-drift.sh"],
        capture_output=True, text=True, check=False,
    )
    assert result.returncode == 0, result.stderr or result.stdout
    assert REPORT.read_bytes() == before_report
    assert DIGEST.read_bytes() == before_digest


def test_gate_status_is_reconciled() -> None:
    """Gate status must use the domain-specific word RECONCILED."""
    gate = json.loads(GATE.read_text(encoding="utf-8"))
    assert gate["status"] == "RECONCILED", f"gate status must be RECONCILED, got {gate['status']}"


def test_report_modules_sorted_alphabetically() -> None:
    """Modules in the report must appear in alphabetical order."""
    text = REPORT.read_text(encoding="utf-8")
    module_names = []
    for line in text.splitlines():
        if line.strip().startswith("- module:"):
            module_names.append(line.strip().split("- module:")[1].strip())
    assert module_names == sorted(module_names), f"modules not sorted: {module_names}"
    assert len(module_names) == EXPECTED_MODULES
