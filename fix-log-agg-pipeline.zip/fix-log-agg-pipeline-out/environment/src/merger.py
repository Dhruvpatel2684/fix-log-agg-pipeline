"""
Segment Merger - merges entries from multiple WAL segments into a single
temporally-ordered stream using k-way merge.
"""
import heapq
from typing import List, Tuple
from .models import LogEntry, WALSegment


class SegmentMerger:
    """Merges multiple WAL segments into a single ordered stream."""

    def merge_segments(self, segments: List[WALSegment]) -> List[LogEntry]:
        """
        K-way merge of segment entries ordered by (timestamp, seq_id).
        """
        if not segments:
            return []

        # Heap entries: (timestamp, tiebreaker, seg_idx, entry_idx)
        # For equal timestamps we need deterministic ordering
        heap: List[Tuple[float, int, int, int]] = []
        for seg_idx, segment in enumerate(segments):
            if segment.entries:
                entry = segment.entries[0]
                heapq.heappush(heap, (entry.timestamp, seg_idx, seg_idx, 0))

        result = []
        while heap:
            _ts, _tie, seg_idx, entry_idx = heapq.heappop(heap)
            entry = segments[seg_idx].entries[entry_idx]
            result.append(entry)

            next_idx = entry_idx + 1
            if next_idx < len(segments[seg_idx].entries):
                next_entry = segments[seg_idx].entries[next_idx]
                heapq.heappush(
                    heap, (next_entry.timestamp, seg_idx, seg_idx, next_idx)
                )

        return result
