#!/bin/bash
set -euo pipefail

# Fix 1: dedup_engine.py - Window boundary must be inclusive (<= not <)
sed -i 's/if window_start < ts < window_end:/if window_start <= ts <= window_end:/' /app/environment/src/dedup_engine.py

# Fix 2: merger.py - Sort by (timestamp, seq_id) not just seq_id
sed -i 's/sorted(all_entries, key=lambda e: e.seq_id)/sorted(all_entries, key=lambda e: (e.timestamp, e.seq_id))/g' /app/environment/src/merger.py

# Fix 3: temporal_index.py - Off-by-one: range(0, len(entries) - 1) -> range(len(entries))
sed -i 's/for i in range(0, len(entries) - 1):/for i in range(len(entries)):/' /app/environment/src/temporal_index.py

# Fix 4: compactor.py - Account for partial_offset in sequence resume
sed -i 's/self._next_seq_id = self._checkpoint.last_seq_id + 1/base_seq = self._checkpoint.last_seq_id\n        if self._checkpoint.partial_segment_id and self._checkpoint.partial_offset > 0:\n            base_seq = self._checkpoint.last_seq_id + self._checkpoint.partial_offset\n        self._next_seq_id = base_seq + 1/' /app/environment/src/compactor.py
