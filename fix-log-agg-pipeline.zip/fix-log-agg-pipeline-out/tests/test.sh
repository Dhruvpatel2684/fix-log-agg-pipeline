#!/bin/bash
set -euo pipefail
cd /app

# Copy tests into the container working directory if not already present
if [ ! -d /app/tests ]; then
    cp -r /task/tests /app/tests 2>/dev/null || true
fi

uv run --with pytest pytest tests/ -v
