#!/bin/bash
set -euo pipefail
cd /app
uv run pytest tests/ -v
