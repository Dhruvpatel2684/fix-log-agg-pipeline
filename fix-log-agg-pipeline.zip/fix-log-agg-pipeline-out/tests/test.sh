#!/bin/bash
set -euo pipefail
cd /app

# The harness places test files alongside this script.
# Copy them into the app working directory for pytest to find.
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
if [ "$SCRIPT_DIR" != "/app/tests" ]; then
    mkdir -p /app/tests
    cp "$SCRIPT_DIR"/*.py /app/tests/ 2>/dev/null || true
fi

uv run pytest tests/ -v
