#!/bin/bash
set -euo pipefail

CONFIG=/etc/cost-audit/cost-audit.conf
FORMATTER=/opt/cost-audit/lib/spend-formatter.sh
BASELINE=/opt/cost-audit/data/spend-records.tsv

# 1. Remove stale PID lock file
rm -f /var/run/cost-audit.pid

# 2. Switch ANOMALY_SCOPE from forecast to actuals
sed -i 's/^ANOMALY_SCOPE=forecast$/#ANOMALY_SCOPE=forecast/' "$CONFIG"
sed -i 's/^#ANOMALY_SCOPE=actuals$/ANOMALY_SCOPE=actuals/' "$CONFIG"

# 3. Enable sourcing of budget-thresholds.conf (production overrides)
sed -i 's|^# \. /etc/cost-audit/budget-thresholds\.conf$|. /etc/cost-audit/budget-thresholds.conf|' "$CONFIG"

# 4. Neutralize the lab-defaults shim
sed -i 's|^\. /etc/cost-audit/overrides\.d/lab-defaults\.conf$|# . /etc/cost-audit/overrides.d/lab-defaults.conf|' "$CONFIG"

# 5. Remove OUTPUT_FORMAT clobber from spend formatter (delete, not change)
tmp="$(mktemp)"
grep -v '^OUTPUT_FORMAT=' "$FORMATTER" >"$tmp"
mv "$tmp" "$FORMATTER"

# 6. Clear restrictive POSIX ACL on reports directory
setfacl -b /var/lib/cost-audit/reports
chmod 755 /var/lib/cost-audit/reports

# 7. Remove corrupt trailing line from spend records
sed -i '$ { /^{/d }' "$BASELINE"

# 8. Execute the anomaly detection pipeline
/opt/cost-audit/bin/detect-anomalies.sh
