#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m pytest test_cost_anomaly.py -v --tb=short 2>&1
