On May 20, 2026, the weekly cloud cost anomaly detection pipeline on finops-node-03 stopped producing audit reports after an incomplete scope migration. The cost governance dashboard flagged the missing report during the Monday morning review.

The FinOps Engineering team staged a migration from "forecast" mode to "actuals" mode but the promotion was never completed. By the time the Sunday 00:00 UTC detection window opened, no new report had reached the expected output location and none has arrived since.

The detection tool refuses to proceed. The on-call engineer observed the following behavior when attempting a manual run: the process exits immediately without producing any output. No error messages appear in the application log, only a brief notice on stderr about operational readiness.

Investigation notes from the previous shift indicate that at least one configuration override layer is still active and interfering with the production settings. There may also be filesystem-level restrictions on the output path that were applied during a prior hardening pass. The spend data input file may have been corrupted by a collector crash that occurred around the same time as the migration attempt.

The entrypoint is at /opt/cost-audit/bin/detect-anomalies.sh. The main configuration lives under /etc/cost-audit/. All issues must be resolved and the pipeline executed successfully.

From where the data is coming:
spend-records.tsv is tab-delimited with header: service_id	owner	department	region	spend_usd	budget_usd	period	category	priority	last_audit

**Required deliverables** — after all fixes are in place, run `/opt/cost-audit/bin/detect-anomalies.sh` and ensure the following files exist:
1. `/var/lib/cost-audit/reports/anomaly-report.yaml` — YAML anomaly report (must land in reports/, not staging/).
2. `/var/lib/cost-audit/reports/report-schema.yaml` — byte-for-byte copy of `/opt/cost-audit/report-schema.yaml`.
3. `/opt/cost-audit/digest.json` — JSON with keys: `artifact`, `sha256`, `departments`.
4. `/opt/cost-audit/gate.json` — JSON with keys: `status`, `departments`.

Processing rules for the anomaly report:
Services in spend-records.tsv should be deduplicated by service_id — only the first occurrence counts. For each qualifying department, compute: total number of unique services, count of budget breaches (spend_usd/budget_usd >= 100%), count of warnings (spend_usd/budget_usd >= 80% but < 100%), average overspend percentage across breaching services only (computed as (spend/budget)*100 - 100 for each breaching service; two decimal places, rounded half-up; 0.00 if no breaches), and audit coverage percentage as the fraction of services whose last_audit is within 168 hours (7 days) of the fixed reference time 2026-05-20T00:00:00Z (two decimal places, rounded half-up). Output departments sorted by department name ascending. All decimal values must have exactly two decimal digits and be quoted strings in the YAML.

The anomaly-report.yaml must be a YAML document with the following exact structure:

```yaml
---
departments:
  - department: <name>
    total_services: <integer>
    breach_count: <integer>
    warning_count: <integer>
    avg_overspend_pct: "<decimal>"
    audit_coverage_pct: "<decimal>"
  - department: ...
    ...
```

Each department entry has exactly these six fields in this order: `department`, `total_services`, `breach_count`, `warning_count`, `avg_overspend_pct`, `audit_coverage_pct`. The list items use two-space indentation under `departments:`, and fields within each item use four-space indentation. Unix LF line endings only. The file must end with a trailing newline.

The digest.json at `/opt/cost-audit/digest.json` requires exactly three keys: `artifact` (absolute path to the report), `sha256` (lowercase hexadecimal SHA-256 digest of the report bytes), and `departments` (integer count of department entries).

The gate.json at `/opt/cost-audit/gate.json` requires exactly two keys: `status` (the string `"FLAGGED"`) and `departments` (integer, must equal the departments count in digest.json). The file must end with a trailing newline.

The full authoritative schema for all output artifacts is in `/opt/cost-audit/report-schema.yaml`, which the pipeline copies as a sidecar next to the report.

**Example** — `{"artifact": "/var/lib/cost-audit/reports/anomaly-report.yaml", "sha256": "abc...", "departments": 4}`

**Example** — `{"status": "FLAGGED", "departments": 4}`
