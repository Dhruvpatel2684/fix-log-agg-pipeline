"""
Tests for fix-cost-anomaly-audit.
All tests must fail on the initial state and pass after solve.sh runs.
"""

from __future__ import annotations

import csv
import hashlib
import json
import subprocess
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

SCHEMA = Path("/opt/cost-audit/report-schema.yaml")
REPORTS_DIR = Path("/var/lib/cost-audit/reports")
STAGING_DIR = Path("/var/lib/cost-audit/staging")
REPORT = REPORTS_DIR / "anomaly-report.yaml"
SIDECAR = REPORTS_DIR / "report-schema.yaml"
DIGEST = Path("/opt/cost-audit/digest.json")
GATE = Path("/opt/cost-audit/gate.json")
CONFIG = Path("/etc/cost-audit/cost-audit.conf")
FORMATTER = Path("/opt/cost-audit/lib/spend-formatter.sh")
BASELINE = Path("/opt/cost-audit/data/spend-records.tsv")
PID_LOCK = Path("/var/run/cost-audit.pid")
EXPECTED_DEPTS = 4
REFERENCE_TIME = "2026-05-20T00:00:00Z"
ACTIVE_SCOPE = "actuals"
AUDIT_WINDOW_HOURS = 168
BREACH_THRESHOLD_PCT = Decimal("100")
WARNING_THRESHOLD_PCT = Decimal("80")

EXPECTED_YAML_LINES = [
    "---",
    "departments:",
    "  - department: data-science",
    "    total_services: 4",
    "    breach_count: 2",
    "    warning_count: 1",
    '    avg_overspend_pct: "39.17"',
    '    audit_coverage_pct: "100.00"',
    "  - department: engineering",
    "    total_services: 5",
    "    breach_count: 3",
    "    warning_count: 1",
    '    avg_overspend_pct: "61.87"',
    '    audit_coverage_pct: "100.00"',
    "  - department: marketing",
    "    total_services: 3",
    "    breach_count: 1",
    "    warning_count: 0",
    '    avg_overspend_pct: "5.00"',
    '    audit_coverage_pct: "33.33"',
    "  - department: operations",
    "    total_services: 3",
    "    breach_count: 3",
    "    warning_count: 0",
    '    avg_overspend_pct: "8.64"',
    '    audit_coverage_pct: "100.00"',
]


def _derive_expected_from_inputs() -> str:
    """Derive expected YAML by applying business rules to on-disk inputs."""
    ref_time = datetime.fromisoformat(REFERENCE_TIME.replace("Z", "+00:00"))
    seen: set = set()
    departments: dict = {}

    with BASELINE.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh, delimiter="\t")
        for lineno, row in enumerate(reader, 2):
            required = {"service_id", "owner", "department", "region", "spend_usd", "budget_usd", "period", "category", "priority", "last_audit"}
            if not required.issubset(set(row.keys())):
                continue
            if any(row[k] is None or row[k].strip() == "" for k in required):
                continue
            try:
                service_id = row["service_id"].strip()
                if service_id in seen:
                    continue
                seen.add(service_id)

                department = row["department"].strip()
                spend = Decimal(row["spend_usd"].strip())
                budget = Decimal(row["budget_usd"].strip())
                last_audit = datetime.fromisoformat(row["last_audit"].strip().replace("Z", "+00:00"))

                spend_pct = (spend / budget) * Decimal("100")
                is_breach = spend_pct >= BREACH_THRESHOLD_PCT
                is_warning = spend_pct >= WARNING_THRESHOLD_PCT and not is_breach
                overspend_pct = max(Decimal("0"), spend_pct - Decimal("100"))

                hours_since = Decimal(str((ref_time - last_audit).total_seconds())) / Decimal("3600")
                is_audited = hours_since <= Decimal(str(AUDIT_WINDOW_HOURS))

                if department not in departments:
                    departments[department] = {
                        "total": 0,
                        "breach": 0,
                        "warning": 0,
                        "overspend_sum": Decimal("0"),
                        "overspend_count": 0,
                        "audited": 0,
                    }
                d = departments[department]
                d["total"] += 1
                if is_breach:
                    d["breach"] += 1
                    d["overspend_sum"] += overspend_pct
                    d["overspend_count"] += 1
                if is_warning:
                    d["warning"] += 1
                if is_audited:
                    d["audited"] += 1
            except (ValueError, KeyError):
                continue

    lines = ["---", "departments:"]
    for dept_name in sorted(departments.keys()):
        d = departments[dept_name]
        if d["overspend_count"] > 0:
            avg_overspend = (d["overspend_sum"] / Decimal(d["overspend_count"])).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        else:
            avg_overspend = Decimal("0.00")
        audit_pct = (Decimal(d["audited"]) / Decimal(d["total"]) * 100).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        lines.append(f"  - department: {dept_name}")
        lines.append(f"    total_services: {d['total']}")
        lines.append(f"    breach_count: {d['breach']}")
        lines.append(f"    warning_count: {d['warning']}")
        lines.append(f'    avg_overspend_pct: "{avg_overspend}"')
        lines.append(f'    audit_coverage_pct: "{audit_pct}"')
    return "\n".join(lines) + "\n"


def test_schema_file_exists() -> None:
    """Environment must ship the report schema."""
    assert SCHEMA.is_file(), "missing /opt/cost-audit/report-schema.yaml"


def test_pid_lock_absent() -> None:
    """Stale PID lock must be removed before the pipeline can run."""
    assert not PID_LOCK.exists(), \
        f"PID lock {PID_LOCK} still present — pipeline will refuse to start"


def test_baseline_no_corrupt_lines() -> None:
    """Every non-header line in spend-records.tsv must be valid tab-delimited data."""
    with BASELINE.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh, delimiter="\t")
        for lineno, row in enumerate(reader, 2):
            required = {"service_id", "owner", "department", "region", "spend_usd", "budget_usd", "period", "category", "priority", "last_audit"}
            missing = required - set(row.keys())
            assert not missing, f"spend-records.tsv:{lineno}: missing fields {missing}"
            for key in required:
                assert row[key] is not None and row[key].strip() != "", \
                    f"spend-records.tsv:{lineno}: empty value for '{key}'"


def test_config_anomaly_scope_actuals() -> None:
    """Anomaly scope must be 'actuals' and budget-thresholds.conf must be sourced."""
    text = CONFIG.read_text(encoding="utf-8")
    lines = [ln.strip() for ln in text.splitlines()]
    assert "ANOMALY_SCOPE=actuals" in lines, "ANOMALY_SCOPE=actuals must be uncommented in cost-audit.conf"
    assert ". /etc/cost-audit/budget-thresholds.conf" in lines, \
        "budget-thresholds.conf must be sourced from cost-audit.conf"
    active_forecast = [ln for ln in lines if ln == "ANOMALY_SCOPE=forecast"]
    assert not active_forecast, "forecast scope must not remain active in cost-audit.conf"


def test_config_lab_shim_neutralized() -> None:
    """Lab override shim must be commented out or removed."""
    text = CONFIG.read_text(encoding="utf-8")
    for raw in text.splitlines():
        stripped = raw.strip()
        if stripped == ". /etc/cost-audit/overrides.d/lab-defaults.conf":
            raise AssertionError("lab-defaults.conf dot-source must be commented out")
    # Accept any commenting style (# with or without space) or full removal
    for raw in text.splitlines():
        stripped = raw.strip()
        if "cost-audit/overrides.d/lab-defaults.conf" in stripped and not stripped.startswith("#"):
            raise AssertionError("neutralize lab shim in cost-audit.conf")


def test_formatter_does_not_override_format() -> None:
    """Spend formatter must not set OUTPUT_FORMAT (clobbers yaml). Lines must be deleted entirely."""
    text = FORMATTER.read_text(encoding="utf-8")
    for raw in text.splitlines():
        stripped = raw.lstrip()
        if stripped.startswith("#"):
            continue
        assert not stripped.startswith("OUTPUT_FORMAT="), \
            "spend-formatter.sh must not set OUTPUT_FORMAT — delete the lines entirely"


def test_formatter_does_not_override_data_path() -> None:
    """Spend formatter must not set SPEND_DATA_PATH (clobbers correct path from config)."""
    text = FORMATTER.read_text(encoding="utf-8")
    for raw in text.splitlines():
        stripped = raw.lstrip()
        if stripped.startswith("#"):
            continue
        assert not stripped.startswith("SPEND_DATA_PATH="), \
            "spend-formatter.sh must not set SPEND_DATA_PATH — delete the line entirely"


def test_reports_dir_no_restrictive_acl() -> None:
    """Reports directory must not have a POSIX ACL that blocks write access."""
    result = subprocess.run(
        ["/bin/bash", "-c", f"getfacl --absolute-names {REPORTS_DIR}"],
        capture_output=True, text=True, check=False,
    )
    if result.returncode == 0:
        for line in result.stdout.splitlines():
            stripped = line.strip()
            if stripped.startswith("user::"):
                perms = stripped.split("::")[1]
                assert "w" in perms, \
                    f"reports directory owner ACL denies write: {stripped}"
    probe = REPORTS_DIR / ".write_probe"
    probe.write_text("ok\n", encoding="utf-8")
    probe.unlink()


def test_report_file_exists() -> None:
    """Primary deliverable must land in the reports directory."""
    assert REPORT.is_file(), "anomaly-report.yaml missing from reports directory"


def test_staging_has_no_report() -> None:
    """Partial fixes that write to staging must not satisfy compliance."""
    staging_yaml = STAGING_DIR / "anomaly-report.yaml"
    assert not staging_yaml.is_file(), "anomaly-report.yaml must not be in staging"


def test_sidecar_schema_beside_report() -> None:
    """Pipeline must emit schema sidecar next to report."""
    assert SIDECAR.is_file(), "missing report-schema.yaml sidecar"
    published = SCHEMA.read_text(encoding="utf-8")
    sidecar = SIDECAR.read_text(encoding="utf-8")
    assert sidecar == published, "sidecar must mirror /opt/cost-audit/report-schema.yaml"


def test_report_yaml_structure() -> None:
    """Report must be valid YAML with correct structure and values."""
    raw = REPORT.read_bytes()
    assert b"\r" not in raw, "anomaly-report.yaml must use Unix LF only"
    assert raw.endswith(b"\n"), "anomaly-report.yaml must end with trailing newline"
    lines = raw.decode("utf-8").splitlines()
    assert lines == EXPECTED_YAML_LINES, \
        f"report content mismatch:\nGOT:\n" + "\n".join(lines[:5]) + "..."


def test_report_departments_sorted_alphabetically() -> None:
    """Departments in the report must appear in alphabetical order."""
    text = REPORT.read_text(encoding="utf-8")
    dept_names = []
    for line in text.splitlines():
        if line.strip().startswith("- department:"):
            dept_names.append(line.strip().split("- department:")[1].strip())
    assert dept_names == sorted(dept_names), f"departments not sorted: {dept_names}"
    assert len(dept_names) == EXPECTED_DEPTS


def test_report_matches_derived_expectation() -> None:
    """Output must match rules applied to on-disk baseline."""
    derived = _derive_expected_from_inputs()
    actual = REPORT.read_text(encoding="utf-8")
    assert actual == derived, "report does not match derived expectation from baseline"


def test_digest_matches_schema() -> None:
    """digest.json must follow schema and match the artifact."""
    digest_obj = json.loads(DIGEST.read_text(encoding="utf-8"))
    assert set(digest_obj.keys()) == {"artifact", "sha256", "departments"}
    computed = hashlib.sha256(REPORT.read_bytes()).hexdigest()
    assert digest_obj["sha256"] == computed
    assert digest_obj["departments"] == EXPECTED_DEPTS
    assert digest_obj["artifact"] == str(REPORT)


def test_gate_matches_schema() -> None:
    """gate.json must use status FLAGGED and departments matching digest."""
    raw = GATE.read_bytes()
    assert raw.endswith(b"\n"), "gate.json must end with trailing newline"
    gate = json.loads(raw.decode("utf-8"))
    assert set(gate.keys()) == {"status", "departments"}
    assert gate["status"] == "FLAGGED"
    digest_obj = json.loads(DIGEST.read_text(encoding="utf-8"))
    assert gate["departments"] == digest_obj["departments"] == EXPECTED_DEPTS


def test_pipeline_exits_zero() -> None:
    """Re-running the pipeline must succeed."""
    result = subprocess.run(
        ["/bin/bash", "/opt/cost-audit/bin/detect-anomalies.sh"],
        capture_output=True, text=True, check=False,
    )
    assert result.returncode == 0, result.stderr or result.stdout


def test_pipeline_rerun_is_byte_identical() -> None:
    """Second run must produce identical output (idempotent)."""
    before_report = REPORT.read_bytes()
    before_digest = DIGEST.read_bytes()
    result = subprocess.run(
        ["/bin/bash", "/opt/cost-audit/bin/detect-anomalies.sh"],
        capture_output=True, text=True, check=False,
    )
    assert result.returncode == 0, result.stderr or result.stdout
    assert REPORT.read_bytes() == before_report
    assert DIGEST.read_bytes() == before_digest


def test_gate_status_is_flagged() -> None:
    """Gate status must use the domain-specific word FLAGGED."""
    gate = json.loads(GATE.read_text(encoding="utf-8"))
    assert gate["status"] == "FLAGGED", f"gate status must be FLAGGED, got {gate['status']}"


def test_no_forecast_scope_in_report() -> None:
    """Report must not contain any reference to forecast scope."""
    text = REPORT.read_text(encoding="utf-8")
    assert "forecast" not in text.lower(), "forecast scope should not appear in report"
