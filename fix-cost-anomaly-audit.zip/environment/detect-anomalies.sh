#!/bin/bash
# Weekly cloud cost anomaly detection pipeline
set -euo pipefail

PID_LOCK=/var/run/cost-audit.pid
if [[ -f "$PID_LOCK" ]]; then
  echo "cost-audit: another instance is running (lock $PID_LOCK present)" >&2
  exit 2
fi

CONFIG=/etc/cost-audit/cost-audit.conf
# shellcheck source=/dev/null
source "$CONFIG"

scope="${ANOMALY_SCOPE:-forecast}"
if [[ "${scope,,}" != "actuals" ]]; then
  echo "cost-audit refused: ANOMALY_SCOPE must be 'actuals' in ${CONFIG}" >&2
  exit 1
fi

# shellcheck source=/dev/null
source /opt/cost-audit/lib/spend-formatter.sh

SPEND_DATA="${SPEND_DATA_PATH:-/opt/cost-audit/data/spend-records.tsv}"
REPORT="${REPORTS_DIR}/anomaly-report.yaml"
DIGEST=/opt/cost-audit/digest.json
GATE=/opt/cost-audit/gate.json
REFERENCE_TIME="2026-05-20T00:00:00Z"

mkdir -p "$REPORTS_DIR"

python3 - "$SPEND_DATA" "$REPORT" "$OUTPUT_FORMAT" "$DIGEST" "$GATE" "$REFERENCE_TIME" "$scope" "${BREACH_THRESHOLD_PCT:-100}" "${WARNING_THRESHOLD_PCT:-80}" "${AUDIT_WINDOW_HOURS:-168}" <<'PY'
import csv
import json
import hashlib
import sys
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

spend_path, report_path, fmt, digest_path, gate_path, ref_time_str, active_scope, breach_pct_str, warning_pct_str, audit_window_str = sys.argv[1:11]

if fmt not in ("yaml", "csv"):
    sys.exit(f"Unknown OUTPUT_FORMAT: {fmt!r} — expected 'yaml'")
if fmt != "yaml":
    sys.exit(f"OUTPUT_FORMAT must be 'yaml', got '{fmt}'")

ref_time = datetime.fromisoformat(ref_time_str.replace("Z", "+00:00"))
audit_window_hours = int(audit_window_str)
breach_threshold = Decimal(breach_pct_str)
warning_threshold = Decimal(warning_pct_str)

# Parse spend records (tab-delimited)
seen_services: set = set()
departments: dict = {}

with open(spend_path, newline="", encoding="utf-8") as fh:
    reader = csv.DictReader(fh, delimiter="\t")
    for lineno, row in enumerate(reader, 2):
        required = {"service_id", "owner", "department", "region", "spend_usd", "budget_usd", "period", "category", "priority", "last_audit"}
        missing = required - set(row.keys())
        if missing:
            sys.exit(f"spend-records.tsv:{lineno}: missing fields {missing}")
        for key in required:
            if row[key] is None or row[key].strip() == "":
                sys.exit(f"spend-records.tsv:{lineno}: empty value for '{key}'")

        service_id = row["service_id"].strip()
        if service_id in seen_services:
            continue
        seen_services.add(service_id)

        department = row["department"].strip()
        spend = Decimal(row["spend_usd"].strip())
        budget = Decimal(row["budget_usd"].strip())
        last_audit = datetime.fromisoformat(row["last_audit"].strip().replace("Z", "+00:00"))

        spend_pct = (spend / budget) * Decimal("100")
        is_breach = spend_pct >= breach_threshold
        is_warning = spend_pct >= warning_threshold and not is_breach
        overspend_pct = max(Decimal("0"), spend_pct - Decimal("100"))

        hours_since_audit = Decimal(str((ref_time - last_audit).total_seconds())) / Decimal("3600")
        is_audited = hours_since_audit <= Decimal(str(audit_window_hours))

        if department not in departments:
            departments[department] = {
                "total": 0,
                "breach": 0,
                "warning": 0,
                "overspend_sum": Decimal("0"),
                "overspend_count": 0,
                "audited": 0,
            }
        d = departments[department]
        d["total"] += 1
        if is_breach:
            d["breach"] += 1
            d["overspend_sum"] += overspend_pct
            d["overspend_count"] += 1
        if is_warning:
            d["warning"] += 1
        if is_audited:
            d["audited"] += 1

# Build YAML output (manual formatting for deterministic output)
lines = ["---", "departments:"]
for dept_name in sorted(departments.keys()):
    d = departments[dept_name]
    if d["overspend_count"] > 0:
        avg_overspend = (d["overspend_sum"] / Decimal(d["overspend_count"])).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    else:
        avg_overspend = Decimal("0.00")
    audit_pct = (Decimal(d["audited"]) / Decimal(d["total"]) * 100).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    lines.append(f"  - department: {dept_name}")
    lines.append(f"    total_services: {d['total']}")
    lines.append(f"    breach_count: {d['breach']}")
    lines.append(f"    warning_count: {d['warning']}")
    lines.append(f'    avg_overspend_pct: "{avg_overspend}"')
    lines.append(f'    audit_coverage_pct: "{audit_pct}"')

yaml_content = "\n".join(lines) + "\n"
Path(report_path).write_text(yaml_content, encoding="utf-8")

# Generate digest
digest = hashlib.sha256(yaml_content.encode("utf-8")).hexdigest()
dept_count = len(departments)
digest_obj = {
    "artifact": str(report_path),
    "sha256": digest,
    "departments": dept_count,
}
Path(digest_path).write_text(json.dumps(digest_obj, indent=2) + "\n")

# Generate gate
Path(gate_path).write_text(
    json.dumps({"status": "FLAGGED", "departments": dept_count}) + "\n"
)

# Copy schema as sidecar
schema_src = Path("/opt/cost-audit/report-schema.yaml")
sidecar = Path(report_path).parent / "report-schema.yaml"
sidecar.write_text(schema_src.read_text(encoding="utf-8"), encoding="utf-8")
PY
