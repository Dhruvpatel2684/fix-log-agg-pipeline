#!/bin/bash
# Weekly firewall rule compliance reconciliation
set -euo pipefail

PID_LOCK=/var/run/fw-audit.pid
if [[ -f "$PID_LOCK" ]]; then
  echo "fw-audit: another instance is running (lock $PID_LOCK present)" >&2
  exit 2
fi

CONFIG=/etc/fw-audit/fw-audit.conf
# shellcheck source=/dev/null
source "$CONFIG"

scope="${RULE_SCOPE:-perimeter}"
if [[ "${scope,,}" != "internal" ]]; then
  echo "fw-audit refused: RULE_SCOPE must be 'internal' in ${CONFIG}" >&2
  exit 1
fi

# shellcheck source=/dev/null
source /opt/fw-audit/lib/report-formatter.sh

BASELINE="${BASELINE_PATH:-/opt/fw-audit/data/rules-export.tsv}"
REPORT="${REPORTS_DIR}/compliance-report.yaml"
DIGEST=/opt/fw-audit/digest.json
GATE=/opt/fw-audit/gate.json
REFERENCE_TIME="2026-05-20T00:00:00Z"

mkdir -p "$REPORTS_DIR"

python3 - "$BASELINE" "$REPORT" "$OUTPUT_FORMAT" "$DIGEST" "$GATE" "$REFERENCE_TIME" "$scope" <<'PY'
import csv
import json
import hashlib
import sys
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

baseline_path, report_path, fmt, digest_path, gate_path, ref_time_str, active_scope = sys.argv[1:8]

if fmt not in ("yaml", "csv"):
    sys.exit(f"Unknown OUTPUT_FORMAT: {fmt!r} — expected 'yaml'")
if fmt != "yaml":
    sys.exit(f"OUTPUT_FORMAT must be 'yaml', got '{fmt}'")

ref_time = datetime.fromisoformat(ref_time_str.replace("Z", "+00:00"))
review_window_hours = 168  # 7 days

SEVERITY_WEIGHTS = {"critical": 4, "high": 3, "medium": 2, "low": 1}

# Parse rules export (tab-delimited)
seen_rules: set = set()
zones: dict = {}

with open(baseline_path, newline="", encoding="utf-8") as fh:
    reader = csv.DictReader(fh, delimiter="\t")
    for lineno, row in enumerate(reader, 2):
        required = {"rule_id", "zone", "rule_name", "scope", "severity", "action", "src_cidr", "dst_cidr", "port", "last_reviewed"}
        missing = required - set(row.keys())
        if missing:
            sys.exit(f"rules-export.tsv:{lineno}: missing fields {missing}")
        for key in required:
            if row[key] is None or row[key].strip() == "":
                sys.exit(f"rules-export.tsv:{lineno}: empty value for '{key}'")

        rule_id = row["rule_id"].strip()
        if rule_id in seen_rules:
            continue
        seen_rules.add(rule_id)

        row_scope = row["scope"].strip().lower()
        if row_scope != active_scope:
            continue

        zone = row["zone"].strip()
        severity = row["severity"].strip().lower()
        action = row["action"].strip().lower()
        last_reviewed = datetime.fromisoformat(row["last_reviewed"].strip().replace("Z", "+00:00"))

        hours_since_review = Decimal(str((ref_time - last_reviewed).total_seconds())) / Decimal("3600")
        is_reviewed = hours_since_review <= Decimal(str(review_window_hours))

        if zone not in zones:
            zones[zone] = {
                "total": 0,
                "deny": 0,
                "allow": 0,
                "severity_sum": Decimal(0),
                "reviewed": 0,
            }
        z = zones[zone]
        z["total"] += 1
        if action == "deny":
            z["deny"] += 1
        else:
            z["allow"] += 1
        z["severity_sum"] += Decimal(str(SEVERITY_WEIGHTS.get(severity, 1)))
        if is_reviewed:
            z["reviewed"] += 1

# Build YAML output (manual formatting for deterministic output)
lines = ["---", "zones:"]
for zone_name in sorted(zones.keys()):
    z = zones[zone_name]
    avg_severity = (z["severity_sum"] / Decimal(z["total"])).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    review_pct = (Decimal(z["reviewed"]) / Decimal(z["total"]) * 100).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    lines.append(f"  - zone: {zone_name}")
    lines.append(f"    total_rules: {z['total']}")
    lines.append(f"    deny_rules: {z['deny']}")
    lines.append(f"    allow_rules: {z['allow']}")
    lines.append(f'    avg_severity_score: "{avg_severity}"')
    lines.append(f'    review_coverage_pct: "{review_pct}"')

yaml_content = "\n".join(lines) + "\n"
Path(report_path).write_text(yaml_content, encoding="utf-8")

# Generate digest
digest = hashlib.sha256(yaml_content.encode("utf-8")).hexdigest()
zone_count = len(zones)
digest_obj = {
    "artifact": str(report_path),
    "sha256": digest,
    "zones": zone_count,
}
Path(digest_path).write_text(json.dumps(digest_obj, indent=2) + "\n")

# Generate gate
Path(gate_path).write_text(
    json.dumps({"status": "ENFORCED", "zones": zone_count}) + "\n"
)

# Copy schema as sidecar
schema_src = Path("/opt/fw-audit/report-schema.yaml")
sidecar = Path(report_path).parent / "report-schema.yaml"
sidecar.write_text(schema_src.read_text(encoding="utf-8"), encoding="utf-8")
PY
