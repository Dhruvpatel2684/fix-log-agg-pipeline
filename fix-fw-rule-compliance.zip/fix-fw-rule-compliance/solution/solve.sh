#!/bin/bash
set -euo pipefail

CONFIG=/etc/fw-audit/fw-audit.conf
FORMATTER=/opt/fw-audit/lib/report-formatter.sh
BASELINE=/opt/fw-audit/data/rules-export.tsv

# 1. Remove stale PID lock file
rm -f /var/run/fw-audit.pid

# 2. Switch RULE_SCOPE from perimeter to internal
sed -i 's/^RULE_SCOPE=perimeter$/#RULE_SCOPE=perimeter/' "$CONFIG"
sed -i 's/^#RULE_SCOPE=internal$/RULE_SCOPE=internal/' "$CONFIG"

# 3. Enable sourcing of policy-baselines.conf (production overrides)
sed -i 's|^# \. /etc/fw-audit/policy-baselines\.conf$|. /etc/fw-audit/policy-baselines.conf|' "$CONFIG"

# 4. Neutralize the lab-override shim
sed -i 's|^\. /etc/fw-audit/shims\.d/lab-override\.conf$|# . /etc/fw-audit/shims.d/lab-override.conf|' "$CONFIG"

# 5. Remove OUTPUT_FORMAT clobber from report formatter (delete, not change)
tmp="$(mktemp)"
grep -v '^OUTPUT_FORMAT=' "$FORMATTER" >"$tmp"
mv "$tmp" "$FORMATTER"

# 6. Clear restrictive POSIX ACL on reports directory
setfacl -b /var/lib/fw-audit/reports
chmod 755 /var/lib/fw-audit/reports

# 7. Remove corrupt trailing line from rules export
sed -i '$ { /^{/d }' "$BASELINE"

# 8. Execute the reconciliation pipeline
/opt/fw-audit/bin/reconcile-rules.sh
