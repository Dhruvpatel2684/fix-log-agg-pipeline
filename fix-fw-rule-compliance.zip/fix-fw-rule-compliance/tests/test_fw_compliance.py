"""
Tests for fix-fw-rule-compliance.
All tests must fail on the initial state and pass after solve.sh runs.
"""

from __future__ import annotations

import csv
import hashlib
import json
import subprocess
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

SCHEMA = Path("/opt/fw-audit/report-schema.yaml")
REPORTS_DIR = Path("/var/lib/fw-audit/reports")
STAGING_DIR = Path("/var/lib/fw-audit/staging")
REPORT = REPORTS_DIR / "compliance-report.yaml"
SIDECAR = REPORTS_DIR / "report-schema.yaml"
DIGEST = Path("/opt/fw-audit/digest.json")
GATE = Path("/opt/fw-audit/gate.json")
CONFIG = Path("/etc/fw-audit/fw-audit.conf")
FORMATTER = Path("/opt/fw-audit/lib/report-formatter.sh")
BASELINE = Path("/opt/fw-audit/data/rules-export.tsv")
PID_LOCK = Path("/var/run/fw-audit.pid")
EXPECTED_ZONES = 3
REFERENCE_TIME = "2026-05-20T00:00:00Z"
ACTIVE_SCOPE = "internal"
REVIEW_WINDOW_HOURS = 168

SEVERITY_WEIGHTS = {"critical": 4, "high": 3, "medium": 2, "low": 1}

EXPECTED_YAML_LINES = [
    "---",
    "zones:",
    "  - zone: corp",
    "    total_rules: 5",
    "    deny_rules: 1",
    "    allow_rules: 4",
    '    avg_severity_score: "1.80"',
    '    review_coverage_pct: "100.00"',
    "  - zone: dmz",
    "    total_rules: 4",
    "    deny_rules: 1",
    "    allow_rules: 3",
    '    avg_severity_score: "2.75"',
    '    review_coverage_pct: "100.00"',
    "  - zone: egress",
    "    total_rules: 4",
    "    deny_rules: 1",
    "    allow_rules: 3",
    '    avg_severity_score: "2.00"',
    '    review_coverage_pct: "75.00"',
]


def _derive_expected_from_inputs() -> str:
    """Derive expected YAML by applying business rules to on-disk inputs."""
    ref_time = datetime.fromisoformat(REFERENCE_TIME.replace("Z", "+00:00"))
    seen: set = set()
    zones: dict = {}

    with BASELINE.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh, delimiter="\t")
        for lineno, row in enumerate(reader, 2):
            required = {"rule_id", "zone", "rule_name", "scope", "severity", "action", "src_cidr", "dst_cidr", "port", "last_reviewed"}
            if not required.issubset(set(row.keys())):
                continue
            if any(row[k] is None or row[k].strip() == "" for k in required):
                continue
            try:
                rule_id = row["rule_id"].strip()
                if rule_id in seen:
                    continue
                seen.add(rule_id)
                if row["scope"].strip().lower() != ACTIVE_SCOPE:
                    continue
                zone = row["zone"].strip()
                severity = row["severity"].strip().lower()
                action = row["action"].strip().lower()
                last_reviewed = datetime.fromisoformat(row["last_reviewed"].strip().replace("Z", "+00:00"))
                hours_since = Decimal(str((ref_time - last_reviewed).total_seconds())) / Decimal("3600")
                is_reviewed = hours_since <= Decimal(str(REVIEW_WINDOW_HOURS))
                if zone not in zones:
                    zones[zone] = {"total": 0, "deny": 0, "allow": 0, "severity_sum": Decimal(0), "reviewed": 0}
                z = zones[zone]
                z["total"] += 1
                if action == "deny":
                    z["deny"] += 1
                else:
                    z["allow"] += 1
                z["severity_sum"] += Decimal(str(SEVERITY_WEIGHTS.get(severity, 1)))
                if is_reviewed:
                    z["reviewed"] += 1
            except (ValueError, KeyError):
                continue

    lines = ["---", "zones:"]
    for zone_name in sorted(zones.keys()):
        z = zones[zone_name]
        avg_severity = (z["severity_sum"] / Decimal(z["total"])).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        review_pct = (Decimal(z["reviewed"]) / Decimal(z["total"]) * 100).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        lines.append(f"  - zone: {zone_name}")
        lines.append(f"    total_rules: {z['total']}")
        lines.append(f"    deny_rules: {z['deny']}")
        lines.append(f"    allow_rules: {z['allow']}")
        lines.append(f'    avg_severity_score: "{avg_severity}"')
        lines.append(f'    review_coverage_pct: "{review_pct}"')
    return "\n".join(lines) + "\n"


def test_schema_file_exists() -> None:
    """Environment must ship the report schema."""
    assert SCHEMA.is_file(), "missing /opt/fw-audit/report-schema.yaml"


def test_pid_lock_absent() -> None:
    """Stale PID lock must be removed before the pipeline can run."""
    assert not PID_LOCK.exists(), \
        f"PID lock {PID_LOCK} still present — pipeline will refuse to start"


def test_baseline_no_corrupt_lines() -> None:
    """Every non-header line in rules-export.tsv must be valid tab-delimited data."""
    with BASELINE.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh, delimiter="\t")
        for lineno, row in enumerate(reader, 2):
            required = {"rule_id", "zone", "rule_name", "scope", "severity", "action", "src_cidr", "dst_cidr", "port", "last_reviewed"}
            missing = required - set(row.keys())
            assert not missing, f"rules-export.tsv:{lineno}: missing fields {missing}"
            for key in required:
                assert row[key] is not None and row[key].strip() != "", \
                    f"rules-export.tsv:{lineno}: empty value for '{key}'"


def test_config_rule_scope_internal() -> None:
    """Rule scope must be 'internal' and policy-baselines.conf must be sourced."""
    text = CONFIG.read_text(encoding="utf-8")
    lines = [ln.strip() for ln in text.splitlines()]
    assert "RULE_SCOPE=internal" in lines, "RULE_SCOPE=internal must be uncommented in fw-audit.conf"
    assert ". /etc/fw-audit/policy-baselines.conf" in lines, \
        "policy-baselines.conf must be sourced from fw-audit.conf"
    active_perimeter = [ln for ln in lines if ln == "RULE_SCOPE=perimeter"]
    assert not active_perimeter, "perimeter scope must not remain active in fw-audit.conf"


def test_config_lab_shim_neutralized() -> None:
    """Lab override shim must be commented out or removed."""
    text = CONFIG.read_text(encoding="utf-8")
    for raw in text.splitlines():
        stripped = raw.strip()
        if stripped == ". /etc/fw-audit/shims.d/lab-override.conf":
            raise AssertionError("lab-override.conf dot-source must be commented out")
    # Accept any commenting style (# with or without space) or full removal
    for raw in text.splitlines():
        stripped = raw.strip()
        if "fw-audit/shims.d/lab-override.conf" in stripped and not stripped.startswith("#"):
            raise AssertionError("neutralize lab shim in fw-audit.conf")


def test_formatter_does_not_override_format() -> None:
    """Report formatter must not set OUTPUT_FORMAT (clobbers yaml). Lines must be deleted entirely."""
    text = FORMATTER.read_text(encoding="utf-8")
    for raw in text.splitlines():
        stripped = raw.lstrip()
        if stripped.startswith("#"):
            continue
        assert not stripped.startswith("OUTPUT_FORMAT="), \
            "report-formatter.sh must not set OUTPUT_FORMAT — delete the lines entirely"


def test_reports_dir_no_restrictive_acl() -> None:
    """Reports directory must not have a POSIX ACL that blocks write access."""
    result = subprocess.run(
        ["getfacl", "--absolute-names", str(REPORTS_DIR)],
        capture_output=True, text=True, check=False,
    )
    if result.returncode == 0:
        for line in result.stdout.splitlines():
            stripped = line.strip()
            if stripped.startswith("user::"):
                perms = stripped.split("::")[1]
                assert "w" in perms, \
                    f"reports directory owner ACL denies write: {stripped}"
    probe = REPORTS_DIR / ".write_probe"
    probe.write_text("ok\n", encoding="utf-8")
    probe.unlink()


def test_report_file_exists() -> None:
    """Primary deliverable must land in the reports directory."""
    assert REPORT.is_file(), "compliance-report.yaml missing from reports directory"


def test_staging_has_no_report() -> None:
    """Partial fixes that write to staging must not satisfy compliance."""
    staging_yaml = STAGING_DIR / "compliance-report.yaml"
    assert not staging_yaml.is_file(), "compliance-report.yaml must not be in staging"


def test_sidecar_schema_beside_report() -> None:
    """Pipeline must emit schema sidecar next to report."""
    assert SIDECAR.is_file(), "missing report-schema.yaml sidecar"
    published = SCHEMA.read_text(encoding="utf-8")
    sidecar = SIDECAR.read_text(encoding="utf-8")
    assert sidecar == published, "sidecar must mirror /opt/fw-audit/report-schema.yaml"


def test_report_yaml_structure() -> None:
    """Report must be valid YAML with correct structure and values."""
    raw = REPORT.read_bytes()
    assert b"\r" not in raw, "compliance-report.yaml must use Unix LF only"
    assert raw.endswith(b"\n"), "compliance-report.yaml must end with trailing newline"
    lines = raw.decode("utf-8").splitlines()
    assert lines == EXPECTED_YAML_LINES, \
        f"report content mismatch:\nGOT:\n" + "\n".join(lines[:5]) + "..."


def test_report_excludes_perimeter_scope() -> None:
    """Perimeter-scope rules must be excluded from the report."""
    text = REPORT.read_text(encoding="utf-8")
    assert "perimeter" not in text.lower(), "perimeter-scope zone/rules must be excluded"


def test_report_matches_derived_expectation() -> None:
    """Output must match rules applied to on-disk baseline."""
    derived = _derive_expected_from_inputs()
    actual = REPORT.read_text(encoding="utf-8")
    assert actual == derived, "report does not match derived expectation from baseline"


def test_digest_matches_schema() -> None:
    """digest.json must follow schema and match the artifact."""
    digest_obj = json.loads(DIGEST.read_text(encoding="utf-8"))
    assert set(digest_obj.keys()) == {"artifact", "sha256", "zones"}
    computed = hashlib.sha256(REPORT.read_bytes()).hexdigest()
    assert digest_obj["sha256"] == computed
    assert digest_obj["zones"] == EXPECTED_ZONES
    assert digest_obj["artifact"] == str(REPORT)


def test_gate_matches_schema() -> None:
    """gate.json must use status ENFORCED and zones matching digest."""
    raw = GATE.read_bytes()
    assert raw.endswith(b"\n"), "gate.json must end with trailing newline"
    gate = json.loads(raw.decode("utf-8"))
    assert set(gate.keys()) == {"status", "zones"}
    assert gate["status"] == "ENFORCED"
    digest_obj = json.loads(DIGEST.read_text(encoding="utf-8"))
    assert gate["zones"] == digest_obj["zones"] == EXPECTED_ZONES


def test_pipeline_exits_zero() -> None:
    """Re-running the pipeline must succeed."""
    result = subprocess.run(
        ["/bin/bash", "/opt/fw-audit/bin/reconcile-rules.sh"],
        capture_output=True, text=True, check=False,
    )
    assert result.returncode == 0, result.stderr or result.stdout


def test_pipeline_rerun_is_byte_identical() -> None:
    """Second run must produce identical output (idempotent)."""
    before_report = REPORT.read_bytes()
    before_digest = DIGEST.read_bytes()
    result = subprocess.run(
        ["/bin/bash", "/opt/fw-audit/bin/reconcile-rules.sh"],
        capture_output=True, text=True, check=False,
    )
    assert result.returncode == 0, result.stderr or result.stdout
    assert REPORT.read_bytes() == before_report
    assert DIGEST.read_bytes() == before_digest


def test_gate_status_is_enforced() -> None:
    """Gate status must use the domain-specific word ENFORCED."""
    gate = json.loads(GATE.read_text(encoding="utf-8"))
    assert gate["status"] == "ENFORCED", f"gate status must be ENFORCED, got {gate['status']}"


def test_report_zones_sorted_alphabetically() -> None:
    """Zones in the report must appear in alphabetical order."""
    text = REPORT.read_text(encoding="utf-8")
    zone_names = []
    for line in text.splitlines():
        if line.strip().startswith("- zone:"):
            zone_names.append(line.strip().split("- zone:")[1].strip())
    assert zone_names == sorted(zone_names), f"zones not sorted: {zone_names}"
    assert len(zone_names) == EXPECTED_ZONES
