On May 20, 2026, the weekly firewall rule compliance reconciliation on border-gw-02 stopped producing audit reports after a scope migration performed by the Network Security Operations team. The compliance dashboard flagged the missing report during the Monday morning review, 24 hours after the expected reconciliation window.

The firewall audit tool on border-gw-02 had been operating normally up to the point of the scope migration. The intent was to migrate all monitored rule sets from "perimeter" scope to "internal" scope, which covers zone-level segmentation rules with tighter review SLAs. The changes were staged incrementally and the migration was never fully completed. By the time the Sunday 00:00 UTC reconciliation window opened, no new report had reached /var/lib/fw-audit/reports/ and none has arrived since.

The reconciliation tool at /opt/fw-audit/bin/reconcile-rules.sh refuses to proceed for multiple reasons. A stale PID lock file at /var/run/fw-audit.pid was left behind by a previous run that was killed mid-execution and was never cleaned up. The tool also validates the active rule scope before doing any work and will exit if it detects anything other than "internal" scope. The production audit parameters — correct reports directory, correct output format — live in /etc/fw-audit/policy-baselines.conf, but that file is not being sourced. A lab environment shim at /etc/fw-audit/shims.d/lab-override.conf runs after the main configuration loads and silently re-applies stale defaults, redirecting the baseline path and forcing CSV format. The shared report formatter library at /opt/fw-audit/lib/report-formatter.sh included by every entrypoint independently assigns OUTPUT_FORMAT, overwriting whatever the config chain established. These OUTPUT_FORMAT assignments in the report formatter must be deleted entirely (not changed to a different value) so that the variable set by policy-baselines.conf survives into the Python processor.

The rules export input file at /opt/fw-audit/data/rules-export.tsv was last appended to by an automated collector that crashed mid-write, leaving a truncated final line that is not valid tab-delimited TSV. The reconciliation tool performs strict row validation and will abort on any malformed input.

During a prior hardening pass, the infrastructure team applied a restrictive POSIX access control list to the reports output directory. The ACL was never relaxed after the initial deployment.

From where the data is coming:
rules-export.tsv is tab-delimited with header: rule_id	zone	rule_name	scope	severity	action	src_cidr	dst_cidr	port	last_reviewed

**Required deliverables** — after all fixes are in place, run `/opt/fw-audit/bin/reconcile-rules.sh` and ensure the following files exist:
1. `/var/lib/fw-audit/reports/compliance-report.yaml` — YAML compliance report (must land in reports/, not staging/).
2. `/var/lib/fw-audit/reports/report-schema.yaml` — byte-for-byte copy of `/opt/fw-audit/report-schema.yaml`.
3. `/opt/fw-audit/digest.json` — JSON with keys: `artifact`, `sha256`, `zones`.
4. `/opt/fw-audit/gate.json` — JSON with keys: `status`, `zones`.

Processing rules for the compliance report:
Rules in rules-export.tsv should be deduplicated by rule_id — only the first occurrence counts. Any rule whose scope does not match the active RULE_SCOPE (internal) must be excluded. For each qualifying zone, compute: total number of unique rules, count of deny rules, count of allow rules (including any non-deny action like 'allow' or 'limit'), average severity score (using weights: critical=4, high=3, medium=2, low=1; two decimal places, rounded half-up), and review coverage percentage as the fraction of rules whose last_reviewed is within 168 hours (7 days) of the fixed reference time 2026-05-20T00:00:00Z (two decimal places, rounded half-up). Output zones sorted by zone name ascending. All decimal values must have exactly two decimal digits and be quoted strings in the YAML.

The compliance-report.yaml must be a YAML document with the following exact structure:

```yaml
---
zones:
  - zone: <name>
    total_rules: <integer>
    deny_rules: <integer>
    allow_rules: <integer>
    avg_severity_score: "<decimal>"
    review_coverage_pct: "<decimal>"
  - zone: ...
    ...
```

Each zone entry has exactly these six fields in this order: `zone`, `total_rules`, `deny_rules`, `allow_rules`, `avg_severity_score`, `review_coverage_pct`. The list items use two-space indentation under `zones:`, and fields within each item use four-space indentation. Unix LF line endings only. The file must end with a trailing newline.

The digest.json at `/opt/fw-audit/digest.json` requires exactly three keys: `artifact` (absolute path to the report), `sha256` (lowercase hexadecimal SHA-256 digest of the report bytes), and `zones` (integer count of zone entries).

The gate.json at `/opt/fw-audit/gate.json` requires exactly two keys: `status` (the string `"ENFORCED"`) and `zones` (integer, must equal the zones count in digest.json). The file must end with a trailing newline.

The full authoritative schema for all output artifacts is also in `/opt/fw-audit/report-schema.yaml`, which the pipeline copies as a sidecar next to the report.

**Example** — `{"artifact": "/var/lib/fw-audit/reports/compliance-report.yaml", "sha256": "abc...", "zones": 3}`

**Example** — `{"status": "ENFORCED", "zones": 3}`
