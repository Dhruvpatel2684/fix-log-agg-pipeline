# Quorum Snapshot Reconciliation — Bug Fix Task

## Overview

You are given a distributed snapshot reconciliation system. The system collects partial state snapshots from multiple replicas, each maintaining key-value pairs annotated with vector clocks for causal ordering and conflict detection. The reconciler merges these partial views into a single consistent global state.

## Architecture

The system consists of the following components:

- **models.py** — Data classes for snapshot entries, replica snapshots, and reconciliation results
- **vector_clock.py** — Vector clock implementation with dominance (causal ordering) and concurrency checks
- **snapshot_store.py** — Loads replica snapshot files from disk
- **merger.py** — Merges entries for the same key using vector clock comparisons and tombstone handling
- **reconciler.py** — Orchestrates the reconciliation pipeline: load → filter → group → merge
- **epoch_tracker.py** — Filters entries based on epoch boundaries relative to the last checkpoint

## How It Works

1. Each replica periodically persists its local state as a JSON snapshot
2. The reconciler loads all replica snapshots and groups entries by key
3. For entries sharing a key, vector clocks determine which is most recent
4. Tombstones (deletion markers) have special precedence rules when clocks are concurrent
5. An epoch-based checkpoint system ensures only unreconciled entries are processed

## Key Concepts

- **Vector Clock Dominance**: Clock A dominates clock B if A causally happened after B — meaning every component of A is at least as large as the corresponding component of B, and they are not identical.
- **Concurrent Clocks**: Two clocks are concurrent if neither dominates the other — there exist components where A > B and others where B > A.
- **Tombstone Precedence**: When a deletion (tombstone) and a value have concurrent clocks, the tombstone should take precedence to prevent "resurrection" of deleted keys.
- **Epoch Filtering**: Entries at or after the checkpoint epoch need reconciliation, since entries exactly at the boundary epoch may not have been fully reconciled in the previous pass.

## Your Task

The system has 3 bugs causing incorrect reconciliation behavior. Find and fix them. The bugs affect:
1. Causal ordering correctness
2. Conflict resolution outcomes
3. Entry filtering completeness

Run the test suite to validate your fixes:

```bash
cd /app && pytest tests/ -v
```

## Files

Source code is in `/app/environment/src/`. Fixtures are in `/app/environment/fixtures/`.
