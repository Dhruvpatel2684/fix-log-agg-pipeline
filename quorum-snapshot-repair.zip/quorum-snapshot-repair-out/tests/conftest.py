"""Shared fixtures for snapshot reconciliation tests."""

import sys
import os
import json
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "environment"))

from src.models import SnapshotEntry, ReplicaSnapshot, ReconciliationResult
from src.vector_clock import VectorClock, make_clock
from src.merger import merge_entries, _resolve_pair
from src.epoch_tracker import filter_by_epoch
from src.reconciler import reconcile_entries, group_by_key


FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "..", "environment", "fixtures")
REPLICAS_DIR = os.path.join(FIXTURES_DIR, "replicas")
CHECKPOINTS_DIR = os.path.join(FIXTURES_DIR, "checkpoints")


@pytest.fixture
def replicas_dir():
    return REPLICAS_DIR


@pytest.fixture
def checkpoints_dir():
    return CHECKPOINTS_DIR


@pytest.fixture
def alpha_snapshot():
    filepath = os.path.join(REPLICAS_DIR, "replica_alpha.json")
    with open(filepath) as f:
        data = json.load(f)
    return ReplicaSnapshot.from_dict(data)


@pytest.fixture
def beta_snapshot():
    filepath = os.path.join(REPLICAS_DIR, "replica_beta.json")
    with open(filepath) as f:
        data = json.load(f)
    return ReplicaSnapshot.from_dict(data)


@pytest.fixture
def gamma_snapshot():
    filepath = os.path.join(REPLICAS_DIR, "replica_gamma.json")
    with open(filepath) as f:
        data = json.load(f)
    return ReplicaSnapshot.from_dict(data)


@pytest.fixture
def all_entries(alpha_snapshot, beta_snapshot, gamma_snapshot):
    entries = []
    entries.extend(alpha_snapshot.entries)
    entries.extend(beta_snapshot.entries)
    entries.extend(gamma_snapshot.entries)
    return entries


@pytest.fixture
def checkpoint_epoch():
    filepath = os.path.join(CHECKPOINTS_DIR, "epoch_5.json")
    with open(filepath) as f:
        data = json.load(f)
    return data["epoch"]
