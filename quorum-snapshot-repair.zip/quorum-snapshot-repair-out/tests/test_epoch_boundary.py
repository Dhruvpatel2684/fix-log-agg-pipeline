"""Tests for epoch boundary filtering."""

import pytest
from src.models import SnapshotEntry
from src.epoch_tracker import filter_by_epoch


class TestEpochFiltering:
    """Verify entries are correctly filtered by epoch boundaries."""

    def test_entries_after_checkpoint_are_included(self):
        """Entries with epoch strictly after checkpoint should be included."""
        entries = [
            SnapshotEntry(key="a", value="1", vector_clock={}, epoch=6, replica_id="r1"),
            SnapshotEntry(key="b", value="2", vector_clock={}, epoch=7, replica_id="r1"),
        ]
        filtered, skipped = filter_by_epoch(entries, checkpoint_epoch=5)
        assert len(filtered) == 2
        assert skipped == 0

    def test_entries_before_checkpoint_are_excluded(self):
        """Entries with epoch before checkpoint should be filtered out."""
        entries = [
            SnapshotEntry(key="a", value="1", vector_clock={}, epoch=3, replica_id="r1"),
            SnapshotEntry(key="b", value="2", vector_clock={}, epoch=4, replica_id="r1"),
        ]
        filtered, skipped = filter_by_epoch(entries, checkpoint_epoch=5)
        assert len(filtered) == 0
        assert skipped == 2

    def test_entries_at_checkpoint_epoch_are_included(self):
        """Entries at exactly the checkpoint epoch should be included for re-reconciliation."""
        entries = [
            SnapshotEntry(key="boundary", value="at_epoch", vector_clock={}, epoch=5, replica_id="r1"),
            SnapshotEntry(key="after", value="past", vector_clock={}, epoch=6, replica_id="r1"),
        ]
        filtered, skipped = filter_by_epoch(entries, checkpoint_epoch=5)
        assert len(filtered) == 2
        keys = [e.key for e in filtered]
        assert "boundary" in keys

    def test_mixed_epochs_correct_partition(self):
        """A mix of entries at various epochs should partition correctly around the boundary."""
        entries = [
            SnapshotEntry(key="e3", value="v", vector_clock={}, epoch=3, replica_id="r1"),
            SnapshotEntry(key="e5", value="v", vector_clock={}, epoch=5, replica_id="r1"),
            SnapshotEntry(key="e6", value="v", vector_clock={}, epoch=6, replica_id="r1"),
            SnapshotEntry(key="e8", value="v", vector_clock={}, epoch=8, replica_id="r1"),
        ]
        filtered, skipped = filter_by_epoch(entries, checkpoint_epoch=5)
        filtered_keys = {e.key for e in filtered}
        assert "e3" not in filtered_keys
        assert "e5" in filtered_keys
        assert "e6" in filtered_keys
        assert "e8" in filtered_keys
        assert skipped == 1
