"""Tests for vector clock causal ordering semantics."""

import pytest
from src.vector_clock import VectorClock, make_clock


class TestVectorClockDominance:
    """Verify correct causal ordering detection."""

    def test_strictly_greater_clock_dominates(self):
        """A clock with all components strictly greater should dominate."""
        a = VectorClock({"alpha": 3, "beta": 2, "gamma": 2})
        b = VectorClock({"alpha": 1, "beta": 1, "gamma": 1})
        assert a.dominates(b)
        assert not b.dominates(a)

    def test_dominance_with_equal_components(self):
        """A clock that advanced on some components while matching others should dominate."""
        a = VectorClock({"alpha": 3, "beta": 2, "gamma": 1})
        b = VectorClock({"alpha": 2, "beta": 2, "gamma": 1})
        assert a.dominates(b)

    def test_dominance_with_single_advance(self):
        """A clock with only one component advanced should still dominate."""
        a = VectorClock({"alpha": 1, "beta": 1, "gamma": 2})
        b = VectorClock({"alpha": 1, "beta": 1, "gamma": 1})
        assert a.dominates(b)

    def test_equal_clocks_do_not_dominate(self):
        """Identical clocks should not report dominance."""
        a = VectorClock({"alpha": 2, "beta": 2, "gamma": 2})
        b = VectorClock({"alpha": 2, "beta": 2, "gamma": 2})
        assert not a.dominates(b)
        assert not b.dominates(a)


class TestVectorClockConcurrency:
    """Verify concurrent clock detection."""

    def test_not_concurrent_when_dominated(self):
        """Clocks with a causal relationship are not concurrent."""
        a = VectorClock({"alpha": 3, "beta": 2, "gamma": 1})
        b = VectorClock({"alpha": 2, "beta": 2, "gamma": 1})
        assert not a.is_concurrent(b)


class TestVectorClockMerge:
    """Verify clock merge produces correct supremum."""

    def test_merge_takes_component_maximum(self):
        """Merged clock should have max of each component."""
        a = VectorClock({"alpha": 3, "beta": 1, "gamma": 2})
        b = VectorClock({"alpha": 1, "beta": 4, "gamma": 2})
        merged = a.merge(b)
        assert merged.get("alpha") == 3
        assert merged.get("beta") == 4
        assert merged.get("gamma") == 2
