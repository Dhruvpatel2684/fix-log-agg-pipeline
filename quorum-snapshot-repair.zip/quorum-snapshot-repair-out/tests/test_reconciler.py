"""Tests for the reconciliation orchestrator."""

import pytest
from src.models import SnapshotEntry
from src.reconciler import reconcile_entries, group_by_key


class TestReconciler:
    """Verify the full reconciliation pipeline."""

    def test_grouping_collects_all_entries_for_key(self):
        """Entries for the same key from different replicas are grouped together."""
        entries = [
            SnapshotEntry(key="x", value="a", vector_clock={"alpha": 1}, epoch=6, replica_id="alpha"),
            SnapshotEntry(key="y", value="b", vector_clock={"beta": 1}, epoch=6, replica_id="beta"),
            SnapshotEntry(key="x", value="c", vector_clock={"gamma": 1}, epoch=6, replica_id="gamma"),
        ]
        grouped = group_by_key(entries)
        assert len(grouped["x"]) == 2
        assert len(grouped["y"]) == 1

    def test_reconcile_filters_and_merges(self):
        """Reconciliation with a checkpoint should filter old entries and merge the rest."""
        entries = [
            SnapshotEntry(key="k1", value="old", vector_clock={"alpha": 1}, epoch=3, replica_id="alpha"),
            SnapshotEntry(key="k1", value="new", vector_clock={"alpha": 2}, epoch=6, replica_id="alpha"),
            SnapshotEntry(key="k2", value="only", vector_clock={"beta": 1}, epoch=7, replica_id="beta"),
        ]
        result = reconcile_entries(entries, checkpoint_epoch=5)
        assert result.total_entries == 2
        assert result.entries_skipped >= 1

    def test_reconcile_handles_three_way_conflict(self):
        """Three entries for the same key should resolve to a single winner."""
        entries = [
            SnapshotEntry(key="m", value="v1", vector_clock={"alpha": 1, "beta": 1, "gamma": 1}, epoch=6, replica_id="alpha"),
            SnapshotEntry(key="m", value="v2", vector_clock={"alpha": 2, "beta": 1, "gamma": 1}, epoch=6, replica_id="beta"),
            SnapshotEntry(key="m", value="v3", vector_clock={"alpha": 2, "beta": 2, "gamma": 1}, epoch=6, replica_id="gamma"),
        ]
        result = reconcile_entries(entries, checkpoint_epoch=0)
        entry = result.get_entry("m")
        assert entry.value == "v3"
