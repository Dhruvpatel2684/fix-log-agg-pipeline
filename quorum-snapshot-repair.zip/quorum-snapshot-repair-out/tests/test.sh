#!/bin/bash
set -euo pipefail
cd /app
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
if [ "$SCRIPT_DIR" != "/app/tests" ]; then
    mkdir -p /app/tests
    cp "$SCRIPT_DIR"/*.py /app/tests/ 2>/dev/null || true
fi
uv run pytest tests/ -v
