"""End-to-end integration tests using fixture data."""

import json
import os
import pytest
from src.models import SnapshotEntry, ReplicaSnapshot
from src.reconciler import reconcile_entries, reconcile_snapshots
from src.epoch_tracker import filter_by_epoch


class TestEndToEnd:
    """Verify complete reconciliation with realistic fixture data."""

    def test_full_reconciliation_from_disk(self, replicas_dir, checkpoints_dir):
        """Load replicas from disk and produce a reconciled result."""
        result = reconcile_snapshots(replicas_dir, checkpoints_dir, "epoch_5")
        assert result.total_entries > 0
        assert result.conflicts_resolved > 0

    def test_user_1002_tombstone_prevails(self, all_entries, checkpoint_epoch):
        """User 1002 has a tombstone from alpha concurrent with a value from beta.
        The tombstone should take precedence in the reconciled state."""
        result = reconcile_entries(all_entries, checkpoint_epoch)
        entry = result.get_entry("user:1002")
        assert entry is not None
        assert entry.is_tombstone is True

    def test_cache_metrics_resolves_to_dominant_entry(self, all_entries, checkpoint_epoch):
        """cache:metrics has entries from alpha (5,3,2), beta (4,4,2), gamma tombstone (4,2,2).
        Alpha's clock dominates gamma's tombstone. Alpha and beta are concurrent.
        The non-tombstone with highest precedence should win."""
        result = reconcile_entries(all_entries, checkpoint_epoch)
        entry = result.get_entry("cache:metrics")
        assert entry is not None
        assert entry.is_tombstone is False

    def test_session_abc_tombstone_from_beta(self, all_entries, checkpoint_epoch):
        """session:abc: beta has tombstone (3,3,2), alpha has value (4,2,2), gamma has value (2,2,4).
        Beta tombstone vs alpha: concurrent (beta has higher beta, alpha has higher alpha).
        Tombstone should prevail over concurrent value."""
        result = reconcile_entries(all_entries, checkpoint_epoch)
        entry = result.get_entry("session:abc")
        assert entry is not None
        assert entry.is_tombstone is True

    def test_entries_at_checkpoint_boundary_are_processed(self, all_entries, checkpoint_epoch):
        """Entries at exactly epoch 5 should be included in reconciliation."""
        filtered, _ = filter_by_epoch(all_entries, checkpoint_epoch)
        epochs_present = {e.epoch for e in filtered}
        assert checkpoint_epoch in epochs_present
