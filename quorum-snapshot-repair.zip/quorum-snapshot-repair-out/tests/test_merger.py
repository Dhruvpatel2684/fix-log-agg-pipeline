"""Tests for entry merging and conflict resolution."""

import pytest
from src.models import SnapshotEntry
from src.vector_clock import VectorClock
from src.merger import merge_entries, _resolve_pair


class TestMergerConflictResolution:
    """Verify conflict resolution rules."""

    def test_dominating_entry_wins(self):
        """Entry with a dominating clock should be the merge winner."""
        entries = {
            "key_a": [
                SnapshotEntry(key="key_a", value="old", vector_clock={"alpha": 1, "beta": 1}, epoch=5, replica_id="alpha"),
                SnapshotEntry(key="key_a", value="new", vector_clock={"alpha": 2, "beta": 1}, epoch=6, replica_id="alpha"),
            ]
        }
        result = merge_entries(entries)
        entry = result.get_entry("key_a")
        assert entry.value == "new"

    def test_tombstone_wins_over_concurrent_value(self):
        """When clocks are concurrent and one is a tombstone, tombstone takes precedence."""
        entries = {
            "key_b": [
                SnapshotEntry(key="key_b", value="alive", vector_clock={"alpha": 2, "beta": 1}, epoch=6, replica_id="alpha", is_tombstone=False),
                SnapshotEntry(key="key_b", value=None, vector_clock={"alpha": 1, "beta": 2}, epoch=6, replica_id="beta", is_tombstone=True),
            ]
        }
        result = merge_entries(entries)
        entry = result.get_entry("key_b")
        assert entry.is_tombstone is True

    def test_tombstone_with_dominating_clock_wins(self):
        """A tombstone whose clock dominates should always win."""
        entries = {
            "key_c": [
                SnapshotEntry(key="key_c", value="data", vector_clock={"alpha": 1, "beta": 1, "gamma": 1}, epoch=5, replica_id="alpha"),
                SnapshotEntry(key="key_c", value=None, vector_clock={"alpha": 2, "beta": 2, "gamma": 1}, epoch=6, replica_id="beta", is_tombstone=True),
            ]
        }
        result = merge_entries(entries)
        entry = result.get_entry("key_c")
        assert entry.is_tombstone is True

    def test_value_with_dominating_clock_wins_over_tombstone(self):
        """A value whose clock dominates a tombstone should win."""
        entries = {
            "key_d": [
                SnapshotEntry(key="key_d", value=None, vector_clock={"alpha": 1, "beta": 1}, epoch=5, replica_id="alpha", is_tombstone=True),
                SnapshotEntry(key="key_d", value="resurrected", vector_clock={"alpha": 2, "beta": 2}, epoch=6, replica_id="beta"),
            ]
        }
        result = merge_entries(entries)
        entry = result.get_entry("key_d")
        assert entry.value == "resurrected"
        assert entry.is_tombstone is False
