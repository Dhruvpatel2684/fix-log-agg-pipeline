#!/bin/bash
set -euo pipefail

python3 << 'EOF'
import os

# Fix 1: vector_clock.py - dominates() uses strict comparison on all components
# The check requires ALL components strictly greater, but correct logic is
# all components >= AND at least one strictly greater (i.e., not equal).
vc_path = "/app/environment/src/vector_clock.py"
with open(vc_path, "r") as f:
    content = f.read()

old_code = """        for replica in all_replicas:
            if self.get(replica) > other.get(replica):
                continue
            else:
                return False
        return True"""

new_code = """        at_least_one_greater = False
        for replica in all_replicas:
            if self.get(replica) > other.get(replica):
                at_least_one_greater = True
            elif self.get(replica) == other.get(replica):
                continue
            else:
                return False
        return at_least_one_greater"""

content = content.replace(old_code, new_code)
with open(vc_path, "w") as f:
    f.write(content)

# Fix 2: merger.py - tombstone precedence logic is inverted
# When clocks are concurrent, tombstone should win (not lose).
merger_path = "/app/environment/src/merger.py"
with open(merger_path, "r") as f:
    content = f.read()

old_code = """    if clock_a.is_concurrent(clock_b):
        if entry_a.is_tombstone and not entry_b.is_tombstone:
            return entry_b, True, False
        elif entry_b.is_tombstone and not entry_a.is_tombstone:
            return entry_a, True, False"""

new_code = """    if clock_a.is_concurrent(clock_b):
        if entry_a.is_tombstone and not entry_b.is_tombstone:
            return entry_a, True, True
        elif entry_b.is_tombstone and not entry_a.is_tombstone:
            return entry_b, True, True"""

content = content.replace(old_code, new_code)
with open(merger_path, "w") as f:
    f.write(content)

# Fix 3: epoch_tracker.py - epoch boundary is exclusive instead of inclusive
# Entries at exactly the checkpoint epoch should be included.
epoch_path = "/app/environment/src/epoch_tracker.py"
with open(epoch_path, "r") as f:
    content = f.read()

content = content.replace(
    "if entry.epoch > checkpoint_epoch:",
    "if entry.epoch >= checkpoint_epoch:"
)
with open(epoch_path, "w") as f:
    f.write(content)

print("All 3 fixes applied successfully.")
EOF
