"""Data models for snapshot reconciliation."""

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class SnapshotEntry:
    """A single key-value entry from a replica snapshot."""
    key: str
    value: Any
    vector_clock: dict
    is_tombstone: bool = False
    epoch: int = 0
    replica_id: str = ""

    def __repr__(self):
        status = "TOMBSTONE" if self.is_tombstone else f"value={self.value!r}"
        return f"SnapshotEntry(key={self.key!r}, {status}, vc={self.vector_clock}, epoch={self.epoch}, replica={self.replica_id})"


@dataclass
class ReplicaSnapshot:
    """A complete snapshot from a single replica."""
    replica_id: str
    entries: list = field(default_factory=list)
    epoch: int = 0

    @classmethod
    def from_dict(cls, data: dict) -> "ReplicaSnapshot":
        """Deserialize from a dictionary."""
        entries = []
        for entry_data in data.get("entries", []):
            entries.append(SnapshotEntry(
                key=entry_data["key"],
                value=entry_data.get("value"),
                vector_clock=entry_data["vector_clock"],
                is_tombstone=entry_data.get("is_tombstone", False),
                epoch=entry_data.get("epoch", 0),
                replica_id=data["replica_id"],
            ))
        return cls(
            replica_id=data["replica_id"],
            entries=entries,
            epoch=data.get("epoch", 0),
        )


@dataclass
class ReconciliationResult:
    """Result of reconciling multiple replica snapshots."""
    entries: list = field(default_factory=list)
    conflicts_resolved: int = 0
    tombstones_applied: int = 0
    entries_skipped: int = 0

    @property
    def total_entries(self) -> int:
        return len(self.entries)

    def get_entry(self, key: str) -> Optional[SnapshotEntry]:
        """Get the reconciled entry for a specific key."""
        for entry in self.entries:
            if entry.key == key:
                return entry
        return None
