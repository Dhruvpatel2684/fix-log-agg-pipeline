"""Main reconciliation orchestrator."""

from typing import Dict, List
from collections import defaultdict

from .models import SnapshotEntry, ReplicaSnapshot, ReconciliationResult
from .snapshot_store import SnapshotStore
from .merger import merge_entries
from .epoch_tracker import filter_by_epoch, load_checkpoint_epoch


def group_by_key(entries: List[SnapshotEntry]) -> Dict[str, List[SnapshotEntry]]:
    """Group entries by their key for conflict resolution."""
    grouped = defaultdict(list)
    for entry in entries:
        grouped[entry.key].append(entry)
    return dict(grouped)


def reconcile_snapshots(
    replicas_dir: str,
    checkpoints_dir: str,
    checkpoint_name: str = "epoch_5"
) -> ReconciliationResult:
    """Run the full reconciliation pipeline.

    Steps:
    1. Load all replica snapshots from disk
    2. Collect all entries across replicas
    3. Filter by epoch (only unreconciled entries)
    4. Group entries by key
    5. Merge entries, resolving conflicts
    6. Return final reconciled state
    """
    store = SnapshotStore(replicas_dir, checkpoints_dir)
    snapshots = store.load_all_snapshots()

    all_entries = []
    for snapshot in snapshots:
        all_entries.extend(snapshot.entries)

    checkpoint_epoch = load_checkpoint_epoch(checkpoints_dir, checkpoint_name)
    filtered_entries, skipped = filter_by_epoch(all_entries, checkpoint_epoch)

    grouped = group_by_key(filtered_entries)
    result = merge_entries(grouped)
    result.entries_skipped = skipped

    return result


def reconcile_entries(
    entries: List[SnapshotEntry],
    checkpoint_epoch: int = 0
) -> ReconciliationResult:
    """Reconcile a list of entries directly (without loading from disk).

    Useful for testing and programmatic usage.
    """
    filtered_entries, skipped = filter_by_epoch(entries, checkpoint_epoch)
    grouped = group_by_key(filtered_entries)
    result = merge_entries(grouped)
    result.entries_skipped = skipped
    return result
