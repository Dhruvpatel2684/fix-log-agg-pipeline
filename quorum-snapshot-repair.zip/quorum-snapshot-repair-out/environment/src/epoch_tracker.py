"""Epoch-based filtering for incremental reconciliation."""

import json
from pathlib import Path
from typing import List

from .models import SnapshotEntry


def load_checkpoint_epoch(checkpoints_dir: str, checkpoint_name: str = "epoch_5") -> int:
    """Load the epoch from a checkpoint file.

    Returns the epoch number from the checkpoint, or 0 if not found.
    """
    checkpoint_path = Path(checkpoints_dir) / f"{checkpoint_name}.json"
    if not checkpoint_path.exists():
        return 0

    with open(checkpoint_path, "r") as f:
        data = json.load(f)
    return data.get("epoch", 0)


def filter_by_epoch(entries: List[SnapshotEntry], checkpoint_epoch: int) -> List[SnapshotEntry]:
    """Filter entries to only those that need reconciliation.

    Entries at or after the checkpoint epoch may not have been fully
    processed in the previous reconciliation pass.
    """
    filtered = []
    skipped = 0
    for entry in entries:
        if entry.epoch > checkpoint_epoch:
            filtered.append(entry)
        else:
            skipped += 1
    return filtered, skipped


def get_unreconciled_entries(
    entries: List[SnapshotEntry],
    checkpoints_dir: str,
    checkpoint_name: str = "epoch_5"
) -> tuple:
    """Load checkpoint and filter entries that need reconciliation.

    Returns (filtered_entries, skipped_count).
    """
    epoch = load_checkpoint_epoch(checkpoints_dir, checkpoint_name)
    return filter_by_epoch(entries, epoch)
