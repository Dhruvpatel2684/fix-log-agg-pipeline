"""Vector clock implementation for causal ordering."""

from typing import Dict


class VectorClock:
    """A vector clock for tracking causal relationships between replicas."""

    def __init__(self, clock: Dict[str, int] = None):
        self._clock = dict(clock) if clock else {}

    @property
    def clock(self) -> Dict[str, int]:
        return dict(self._clock)

    def get(self, replica_id: str) -> int:
        """Get the counter for a specific replica."""
        return self._clock.get(replica_id, 0)

    def increment(self, replica_id: str) -> "VectorClock":
        """Return a new VectorClock with the given replica's counter incremented."""
        new_clock = dict(self._clock)
        new_clock[replica_id] = new_clock.get(replica_id, 0) + 1
        return VectorClock(new_clock)

    def all_replicas(self) -> set:
        """Get all replica IDs tracked by this clock."""
        return set(self._clock.keys())

    def dominates(self, other: "VectorClock") -> bool:
        """Check if this clock causally dominates (happened-after) another clock.

        Returns True if this clock represents a state that happened after
        the state represented by the other clock.
        """
        all_replicas = self.all_replicas() | other.all_replicas()
        if not all_replicas:
            return False

        for replica in all_replicas:
            if self.get(replica) > other.get(replica):
                continue
            else:
                return False
        return True

    def is_concurrent(self, other: "VectorClock") -> bool:
        """Check if this clock is concurrent with another (neither dominates).

        Two events are concurrent if neither happened before the other.
        """
        return not self.dominates(other) and not other.dominates(self) and self != other

    def merge(self, other: "VectorClock") -> "VectorClock":
        """Merge two vector clocks by taking the maximum of each component."""
        all_replicas = self.all_replicas() | other.all_replicas()
        merged = {}
        for replica in all_replicas:
            merged[replica] = max(self.get(replica), other.get(replica))
        return VectorClock(merged)

    def __eq__(self, other):
        if not isinstance(other, VectorClock):
            return False
        all_replicas = self.all_replicas() | other.all_replicas()
        return all(self.get(r) == other.get(r) for r in all_replicas)

    def __hash__(self):
        return hash(frozenset(self._clock.items()))

    def __repr__(self):
        return f"VectorClock({self._clock})"


def make_clock(clock_dict: dict) -> VectorClock:
    """Helper to create a VectorClock from a dictionary."""
    return VectorClock(clock_dict)
