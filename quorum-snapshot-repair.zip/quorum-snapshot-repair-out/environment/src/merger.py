"""Entry merging with conflict resolution."""

from typing import Dict, List, Tuple

from .models import SnapshotEntry, ReconciliationResult
from .vector_clock import VectorClock


def _to_vclock(entry: SnapshotEntry) -> VectorClock:
    """Convert an entry's vector_clock dict to a VectorClock object."""
    return VectorClock(entry.vector_clock)


def _resolve_pair(entry_a: SnapshotEntry, entry_b: SnapshotEntry) -> Tuple[SnapshotEntry, bool, bool]:
    """Resolve a conflict between two entries for the same key.

    Returns: (winning_entry, was_conflict, tombstone_applied)
    """
    clock_a = _to_vclock(entry_a)
    clock_b = _to_vclock(entry_b)

    if clock_a.dominates(clock_b):
        return entry_a, True, entry_a.is_tombstone

    if clock_b.dominates(clock_a):
        return entry_b, True, entry_b.is_tombstone

    if clock_a.is_concurrent(clock_b):
        if entry_a.is_tombstone and not entry_b.is_tombstone:
            return entry_b, True, False
        elif entry_b.is_tombstone and not entry_a.is_tombstone:
            return entry_a, True, False
        elif entry_a.is_tombstone and entry_b.is_tombstone:
            return entry_a, True, True
        else:
            if entry_a.replica_id <= entry_b.replica_id:
                return entry_a, True, False
            else:
                return entry_b, True, False

    return entry_a, False, False


def merge_entries(entries_by_key: Dict[str, List[SnapshotEntry]]) -> ReconciliationResult:
    """Merge grouped entries, resolving conflicts via vector clock comparison.

    For each key with multiple entries, determines which entry wins based on
    causal ordering and tombstone precedence rules.
    """
    result = ReconciliationResult()

    for key, entries in sorted(entries_by_key.items()):
        if not entries:
            continue

        if len(entries) == 1:
            result.entries.append(entries[0])
            continue

        winner = entries[0]
        for i in range(1, len(entries)):
            winner, was_conflict, tombstone_applied = _resolve_pair(winner, entries[i])
            if was_conflict:
                result.conflicts_resolved += 1
            if tombstone_applied:
                result.tombstones_applied += 1

        result.entries.append(winner)

    return result
