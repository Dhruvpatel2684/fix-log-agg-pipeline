"""Snapshot storage and loading utilities."""

import json
import os
from pathlib import Path
from typing import List

from .models import ReplicaSnapshot


class SnapshotStore:
    """Loads and manages replica snapshots from the filesystem."""

    def __init__(self, replicas_dir: str, checkpoints_dir: str = None):
        self.replicas_dir = Path(replicas_dir)
        self.checkpoints_dir = Path(checkpoints_dir) if checkpoints_dir else None

    def load_all_snapshots(self) -> List[ReplicaSnapshot]:
        """Load all replica snapshot files from the replicas directory."""
        snapshots = []
        if not self.replicas_dir.exists():
            return snapshots

        for filepath in sorted(self.replicas_dir.glob("*.json")):
            snapshot = self._load_snapshot(filepath)
            if snapshot:
                snapshots.append(snapshot)
        return snapshots

    def load_checkpoint_epoch(self, checkpoint_name: str) -> int:
        """Load the epoch value from a checkpoint file."""
        if not self.checkpoints_dir:
            return 0

        checkpoint_path = self.checkpoints_dir / f"{checkpoint_name}.json"
        if not checkpoint_path.exists():
            return 0

        with open(checkpoint_path, "r") as f:
            data = json.load(f)
        return data.get("epoch", 0)

    def _load_snapshot(self, filepath: Path) -> ReplicaSnapshot:
        """Load a single snapshot file."""
        try:
            with open(filepath, "r") as f:
                data = json.load(f)
            return ReplicaSnapshot.from_dict(data)
        except (json.JSONDecodeError, KeyError, TypeError) as e:
            print(f"Warning: Failed to load snapshot {filepath}: {e}")
            return None
