On May 19, 2026, the nightly DNS zone drift reconciliation on ns-gw-03 stopped producing audit reports after a split-horizon policy refresh performed by the Network Engineering team. The service mesh health dashboard flagged multiple internal resolution failures the following morning, traced back to the missing drift report that gates automated remediation.

The zone-audit reconciliation tool on ns-gw-03 had been operating normally prior to the policy refresh. The intent was to switch the auditor from monitoring the external (public-facing) view to the internal (service mesh) view, which has stricter SLA requirements. The transition was staged incrementally and never fully completed. By the time the Monday 01:00 UTC audit window opened, no new drift report had reached /var/lib/zone-audit/reports/ and none has arrived since.

The reconciliation tool at /opt/zone-audit/bin/reconcile-zones.sh refuses to proceed for multiple reasons. A stale PID file was left behind by a crashed previous run and was never cleaned up. The tool validates the active audit view before doing any work and exits immediately if it detects anything other than "internal" view. The production view parameters — correct reports directory, correct report format — live in /etc/zone-audit/view-internal.conf, but that file is not being sourced. A resolver backward-compatibility shim runs after the main configuration loads and silently re-applies the old external-view defaults. The shared format library included by every entrypoint independently assigns the report format variable, overwriting whatever the config chain established.

The zone export input file was last appended to by an automated zone-transfer collector that crashed mid-write, leaving a truncated final line that is not valid tab-delimited data. The reconciliation tool performs strict row validation and will abort on any malformed input.

During a prior hardening pass, the infrastructure team applied a restrictive POSIX access control list to the reports output directory. The ACL was never relaxed after initial deployment.

From where the data is coming:
service-registry.json is a JSON array of expected DNS records with fields: fqdn, record_type, expected_value, service_owner, priority.
zone-export.tsv is tab-delimited with fields: fqdn, record_type, value, ttl, view, serial.

**Required deliverables** — after all fixes are in place, run `/opt/zone-audit/bin/reconcile-zones.sh` and ensure:
1. `/var/lib/zone-audit/reports/drift-report.yaml` — YAML zone drift report (must land in reports/, not scratch/).
2. `/var/lib/zone-audit/reports/audit-schema.yaml` — byte-for-byte copy of `/opt/zone-audit/audit-schema.yaml`.
3. `/opt/zone-audit/digest.json` — JSON with keys: `artifact`, `sha256`, `owners`.
4. `/opt/zone-audit/gate.json` — JSON with keys: `status`, `owners`.

Processing rules for the drift report:
The tool reconciles the service registry against the zone export. Only registry entries whose fqdn matches the active view suffix (.internal for internal view) are included. Zone export records are filtered to only those matching the active view column, then deduplicated by (fqdn, record_type) keeping the first occurrence. For each service_owner, compute: total registry entries, count of matched records (zone value equals expected_value), count of drifted records, and drift percentage (drifted/total as percentage, rounded half-up to two decimal places). Output owners sorted alphabetically. The YAML uses the structure defined in the schema. Drift percentages must be quoted strings with exactly two decimal digits.

The gate.json status value must be `"RECONCILED"`. The `owners` count must equal the number of owner entries in the report.

The full schema is in `/opt/zone-audit/audit-schema.yaml`.

**Example** — `{"artifact": "/var/lib/zone-audit/reports/drift-report.yaml", "sha256": "abc...", "owners": 4}`

**Example** — `{"status": "RECONCILED", "owners": 4}`
